﻿using Http503StatusCode.Models;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;

namespace Http503StatusCode.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class EmployeeController : ControllerBase
    {
        //public IConfiguration _configuration; 
        //public EmployeeController(IConfiguration configuration)
        //{
        //    _configuration = configuration;
        //} 
        //[HttpGet]
        //public IActionResult GetResource()
        //{ 
        //    bool IsUnderMaintenance = Convert.ToBoolean(_configuration["IsApplicationUnderMaintenance"]); 
        //    if (IsUnderMaintenance)
        //    { 
        //        var customResponse = new
        //        {
        //            Code = 503,
        //            Message = "Service is under maintenance. Please try again later."
        //        }; 
        //        return StatusCode(503, customResponse);
        //    } 
        //    return Ok("Service is Available");
        //}

        //================================
        //[HttpGet]
        //public IActionResult GetResource()
        //{
        //    return Ok("Service is Available");
        //}
        //=============================================================
        private readonly IMyService _myService;
        public EmployeeController(IMyService myService)
        {
            _myService = myService;
        }
        [HttpGet]
        public async Task<IActionResult> GetExternalData()
        {
            try
            {
                var data = await _myService.GetExternalDataAsync();
                return Ok(data);
            }
            catch (HttpRequestException ex) 
            
            when (ex.StatusCode == System.Net.HttpStatusCode.ServiceUnavailable)
            {
                var customResponse = new
                {
                    Code = 503,
                    Message = "Service is temporarily unavailable. Please try again later.",
                };
                return StatusCode(503, customResponse);
            }
            catch (Exception)
            {
                var customResponse = new
                {
                    Code = 500,
                    Message = "An internal server error occurred. Please try again later.",
                };
                return StatusCode(500, customResponse);
            }
        }
    }
}
