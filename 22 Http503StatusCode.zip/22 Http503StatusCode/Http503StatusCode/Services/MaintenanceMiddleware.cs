﻿using System.Text.Json;
namespace Http503StatusCode.Services
{
    public class MaintenanceMiddleware
    {
        private readonly RequestDelegate _next; 
        public MaintenanceMiddleware(RequestDelegate next)
        { 
            _next = next;
        } 
        public async Task Invoke(HttpContext httpContext, IConfiguration configuration)
        { 
            bool IsUnderMaintenance = Convert.ToBoolean(configuration["IsApplicationUnderMaintenance"]); 
            if (IsUnderMaintenance)
            { 
                httpContext.Response.StatusCode = StatusCodes.Status503ServiceUnavailable; 
                httpContext.Response.ContentType = "application/json"; 
                httpContext.Response.Headers["Retry-After"] = "120"; 
                var customResponse = new
                {
                    Code = 503,
                    Message = "Service is under maintenance. Please try again later."
                }; 
                var responseJson = JsonSerializer.Serialize(customResponse); 
                await httpContext.Response.WriteAsync(responseJson);
            }
            else
            { 
                await _next(httpContext);
            }
        }
    }
}
