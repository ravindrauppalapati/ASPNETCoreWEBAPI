﻿using Polly; 
using Polly.Extensions.Http;
namespace Http503StatusCode.Models
{
    public class PollyPolicies
    {
        public static IAsyncPolicy<HttpResponseMessage> GetRetryPolicy()
        { 
            return HttpPolicyExtensions
                  .HandleTransientHttpError()
                  .WaitAndRetryAsync(
                    3,  
                    retryAttempt => TimeSpan.FromSeconds(Math.Pow(2, retryAttempt))
                  );
        }
    }
}
