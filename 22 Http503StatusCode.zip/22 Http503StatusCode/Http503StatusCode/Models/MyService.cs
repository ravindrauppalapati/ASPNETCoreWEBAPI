﻿namespace Http503StatusCode.Models
{
    public interface IMyService
    {   
        Task<string> GetExternalDataAsync();
    } 
    public class MyService : IMyService
    { 
        private readonly HttpClient _httpClient; 
        public MyService(HttpClient httpClient)
        { 
            _httpClient = httpClient;
        } 
        public async Task<string> GetExternalDataAsync()
        { 
            var response = await _httpClient.GetAsync("https://httpstat.us/503"); 
            if (response.IsSuccessStatusCode)
            { 
                return await response.Content.ReadAsStringAsync();
            }
            else if (response.StatusCode == System.Net.HttpStatusCode.ServiceUnavailable)
            { 
                throw new HttpRequestException("Service is temporarily unavailable.", null, System.Net.HttpStatusCode.ServiceUnavailable);
            }
            else
            { 
                throw new HttpRequestException($"Request failed with status code: {response.StatusCode}");
            }
        }
    }
}
