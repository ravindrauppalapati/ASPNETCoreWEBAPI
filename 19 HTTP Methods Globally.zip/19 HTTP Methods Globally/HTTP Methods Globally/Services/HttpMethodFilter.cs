﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Filters;

namespace HTTP_Methods_Globally.Services
{
    public class HttpMethodFilter : IActionFilter
    {
        private readonly string[] _allowedMethods; 
        public HttpMethodFilter(string[] allowedMethods)
        { 
            _allowedMethods = allowedMethods;
        }
        public void OnActionExecuted(ActionExecutedContext context)
        {
            throw new NotImplementedException();
        }

        public void OnActionExecuting(ActionExecutingContext context)
        {
            if (!_allowedMethods.Contains(context.HttpContext.Request.Method))
            { 
                var customResponse = new
                {
                    Code = 405,  
                    Message = "HTTP Method not allowed"   
                }; 
                context.Result = new ObjectResult(customResponse)
                {
                    StatusCode = 405   
                };
            }
        }
    }
}
