﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;

namespace HTTP_Methods_Globally.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class EmployeeController : ControllerBase
    {
        [HttpGet]
        public IActionResult GetAction()
        {
            return Ok("GetAction Data processed");
        } 
        [HttpPost]
        public IActionResult PostAction()
        {
            return Ok("PostAction Data Processed");
        } 
        [HttpPut]
        public IActionResult PutAction()
        {
            return Ok("PutAction Data processed");
        } 
        [HttpPatch]
        public IActionResult PatchAction()
        {
            return Ok("PatchAction Data processed");
        } 
        [HttpDelete]
        public IActionResult DeleteAction()
        {
            return Ok("DeleteAction Data processed");
        }
    }
}
