﻿using AutoMapper;
using AutoMapperPreCondition.DTOs;
using AutoMapperPreCondition.Models;

namespace AutoMapperPreCondition.Services
{
    public class MappingProfile : Profile
    {
        public MappingProfile()
        {
            //CreateMap<Product, ProductDTO>()
            //    .ForMember(dest => dest.Price, opts =>
            //    {
            //        opts.PreCondition(src => src.InStock);
            //        opts.MapFrom(src => src.Price);
            //    });


            CreateMap<Product, ProductDTO>()
                .ForMember(dest => dest.Price, act =>
                {
                    act.PreCondition(src => CustomMapping.mapPrice(src));
                    act.MapFrom(src => src.Price);
                });

        }
    }
}
