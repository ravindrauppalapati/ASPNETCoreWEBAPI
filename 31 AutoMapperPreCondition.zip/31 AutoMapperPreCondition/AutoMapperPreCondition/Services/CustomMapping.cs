﻿using AutoMapperPreCondition.Models;

namespace AutoMapperPreCondition.Services
{
    public class CustomMapping
    {
        public static bool mapPrice(Product product)
        {
            return product.InStock && product.Category == "Electronics";
        }

        public static bool mapPrice(bool stock, string category)
        {
            return stock && category == "Electronics";
        }
    }
}
