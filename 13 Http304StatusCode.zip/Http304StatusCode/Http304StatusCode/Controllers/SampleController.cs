﻿using Http304StatusCode.Models;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;

namespace Http304StatusCode.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class SampleController : ControllerBase
    {
        [HttpGet("{id}")] 
        [ResponseCache(Duration = 60, Location = ResponseCacheLocation.Client, NoStore = false)]
        public IActionResult Get(int id)
        { 
            var resource = GetResourceById(id); 
            if (resource == null)
            { 
                return NotFound();
            } 

            var lastModified = resource.LastModified.ToUniversalTime(); 
           
            var eTag = $"{lastModified.Ticks}"; 
            
            if (Request.Headers.ContainsKey("If-None-Match") && Request.Headers["If-None-Match"].ToString() == eTag)
            { 
                return StatusCode(StatusCodes.Status304NotModified);
            }

             if (Request.Headers.ContainsKey("If-Modified-Since") && DateTime.TryParse(Request.Headers["If-Modified-Since"], out DateTime ifModifiedSince) && ifModifiedSince >= lastModified)
            {
                 return StatusCode(StatusCodes.Status304NotModified);
            }
              Response.Headers["ETag"] = eTag;
             Response.Headers["Last-Modified"] = lastModified.ToString("R");
             return Ok(resource);
        }
         
        private Resource GetResourceById(int id)
        {
             return new Resource
            {
                Id = id,
                Content = "Sample Content",  
                LastModified = Convert.ToDateTime("04-08-2024 04:24:37")  
            };
        }
    }
}
