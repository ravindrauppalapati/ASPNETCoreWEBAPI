﻿using AutoMapper;
using AutoMapping_PrimitiveTypes.DTOs;
using AutoMapping_PrimitiveTypes.Models;
namespace AutoMapping_PrimitiveTypes.Services
{
    public class MappingProfile : Profile
    {

        public MappingProfile() 
        {
            //CreateMap<User, UserDTO>()
            //    .ForMember(dest => dest.City, act => act.MapFrom(src => src.address.City))
            //    .ForMember(dest => dest.State, act => act.MapFrom(src => src.address.State))
            //    .ForMember(dest => dest.Country, act => act.MapFrom(src => src.address.Country));

            CreateMap<User, UserDTO>()
                .ForMember(dest => dest.Address, act => act.MapFrom(src => new AddressDTO()
                {
                    City = src.City,
                    State = src.State,
                    Country = src.Country
                }));

        }

    }
}
