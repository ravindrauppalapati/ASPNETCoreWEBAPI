﻿namespace AutoMapping_PrimitiveTypes.DTOs
{
    public class AddressDTO
    {
        public string City { get; set; }
        public string State { get; set; }
        public string Country { get; set; }
    }
}
