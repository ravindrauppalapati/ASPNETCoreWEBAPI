﻿using HttpStatusCode201.Models;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;

namespace HttpStatusCode201.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class EmployeeController : ControllerBase
    {
        public List<Employee> employees = new List<Employee>()
        {
            new Employee(){ Id=1,Name="AAA",Gender="Male",PhoneNo="12345",Address="GTR"},
            new Employee(){ Id=2,Name="BBB",Gender="FeMale",PhoneNo="12342",Address="VJW"},
            new Employee(){ Id=3,Name="CCC",Gender="Male",PhoneNo="12343",Address="VZG"},
            new Employee(){ Id=4,Name="DDD",Gender="FeMale",PhoneNo="12344",Address="ONG"},
            new Employee(){ Id=5,Name="EEE",Gender="Male",PhoneNo="12341",Address="TNL"}
        };

        [HttpGet("{id}",Name ="GetEmployeeById")]
        public ActionResult<Employee> getEmployee(int id)
        {
            var emp = employees.Where(x => x.Id == id);
            if(emp == null)
            {
                return NotFound();
            }
            return Ok(emp);
        }

        //[HttpPost]
        //public ActionResult<Employee> createEmployee(Employee employee)
        //{
        //    employee.Id = employees.Count() + 1;
        //    employees.Add(employee);
        //    return Created();
        //}

        [HttpPost]
        //public ActionResult<Employee> createEmployee1(Employee employee)
        //{
        //    employee.Id = employees.Count() + 1;
        //    employees.Add(employee);
        //    var locationUrl = Url.Action("getEmployee",new {id =employee.Id});
        //    return Created(locationUrl,employee);
        //}

        [HttpPost]
        public ActionResult<Employee> createEmployee2(Employee employee)
        {
            employee.Id = employees.Count() + 1;
            employees.Add(employee);
            var locationUrl = Url.Link("getEmployee", new { id = employee.Id });
            return Created(locationUrl, employee);
        }
    }
}
