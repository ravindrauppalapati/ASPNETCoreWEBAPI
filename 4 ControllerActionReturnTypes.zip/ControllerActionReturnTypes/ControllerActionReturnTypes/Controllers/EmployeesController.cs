﻿using ControllerActionReturnTypes.Models;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;

namespace ControllerActionReturnTypes.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class EmployeesController : ControllerBase
    {
        [HttpGet("name")]
        public string GetName()
        {
            return "Return from GetName";
        }

        [HttpGet("Details")]
        public Employee GetEmployeeDetails()
        {
            return new Employee()
            {
                Id = 1,
                Name = "Ravindra",
                Gender = "Male",
                Age = 35,
                City = "Guntur",
                Department = "IT"
            };

        }

       public static readonly   List<Employee> emplist = new List<Employee>()
            {
                new Employee()
               { Id = 1,
                Name = "Ravindra",
                Gender = "Male",
                Age = 35,
                City = "Guntur",
                Department = "IT"
               },
               new Employee()
               { Id = 2,
                Name = "Ravindra",
                Gender = "Male",
                Age = 35,
                City = "Guntur",
                Department = "IT"
               },new Employee()
               { Id = 3,
                Name = "Ravindra",
                Gender = "Male",
                Age = 35,
                City = "Guntur",
                Department = "IT"
               }
            };

        // [HttpGet("All")]
        //public IEnumerable<Employee> GetEmployees() 
        //{
        //    return new List<Employee>()
        //    {
        //       new Employee()
        //       { Id = 1,
        //        Name = "Ravindra",
        //        Gender = "Male",
        //        Age = 35,
        //        City = "Guntur",
        //        Department = "IT" 
        //       },
        //       new Employee()
        //       { Id = 2,
        //        Name = "Ravindra",
        //        Gender = "Male",
        //        Age = 35,
        //        City = "Guntur",
        //        Department = "IT"
        //       },new Employee()
        //       { Id = 3,
        //        Name = "Ravindra",
        //        Gender = "Male",
        //        Age = 35,
        //        City = "Guntur",
        //        Department = "IT"
        //       }
        //    };
        // }

        [HttpGet]
        //[ProducesResponseType(StatusCodes.Status200OK,Type =typeof(List<Employee>))]
        //[ProducesResponseType(StatusCodes.Status404NotFound)]
        //[ProducesResponseType(StatusCodes.Status500InternalServerError)]

        //public async  Task<IActionResult> GetAllEmployee()
        public async Task<ActionResult<IList<Employee>>> GetAllEmployee()
        {
            try
            { await Task.Delay(TimeSpan.FromSeconds(1));
                return Ok(emplist); 
            }
            catch (Exception ex)
            {
                return StatusCode(500, "Internal Server Error");
            }
           
        }

        [HttpGet("{Id}")]
        //[ProducesResponseType(StatusCodes.Status200OK,Type =typeof(List<Employee>))]
        //[ProducesResponseType(StatusCodes.Status404NotFound)]
        //[ProducesResponseType(StatusCodes.Status500InternalServerError)]

        public async Task<ActionResult<Employee>> GetEmployeeById(int Id)
        {
            try
            {
                await Task.Delay(TimeSpan.FromSeconds(1));
                var emp = emplist.FirstOrDefault(x => x.Id == Id);
                if (emp == null)
                    return NotFound(new {Message = $"{Id} Not Found"});

                return Ok(emp);
            }
            catch (Exception ex)
            {
                return StatusCode(500, "Internal Server Error");
            }

        }
    }
}
