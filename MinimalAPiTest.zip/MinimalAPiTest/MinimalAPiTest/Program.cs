using MinimalAPiTest;

var builder = WebApplication.CreateBuilder(args);

// Add services to the container.
// Learn more about configuring Swagger/OpenAPI at https://aka.ms/aspnetcore/swashbuckle
builder.Services.AddEndpointsApiExplorer();
builder.Services.AddSwaggerGen();
builder.Services.AddSingleton<IEmployeeService,EmployeeService>();
var app = builder.Build();

// Configure the HTTP request pipeline.
if (app.Environment.IsDevelopment())
{
    app.UseSwagger();
    app.UseSwaggerUI();
}

app.UseHttpsRedirection();



//var employeeList = new List<Employee>
//{
//    new Employee { Id = 1, Name = "Ravindra", Position = "Software Engineer", Salary = 60000 },
//    new Employee { Id = 2, Name = "Surendra", Position = "Project Manager", Salary = 80000 }
//};

app.MapGet("/employees", (IEmployeeService employeeService) => employeeService.GetAllEmployees());
//app.MapGet("/employees", (IEmployeeService employeeService) => employeeService.GetAllEmployees());

//app.MapGet("/employees", () => employeeList);

app.MapGet("/employees/{id}", (int id, IEmployeeService employeeService) =>
{
    var employee = employeeService.GetEmployeeById(id);
    return employee is not null ? Results.Ok(employee) : Results.NotFound();
});

//app.MapGet("/employees/{id}", (int id, IEmployeeService employeeService) =>
//{
//    var employee = employeeService.GetEmployeeById(id);
//    return employee is not null ? Results.Ok(employee) : Results.NotFound();
//});
//app.MapGet("/employees/{id}", (int id) =>
//{
//    var employee = employeeList.FirstOrDefault(e => e.Id == id);
//    return employee is not null ? Results.Ok(employee) : Results.NotFound();
//});

//app.MapPost("/employees", (Employee newEmployee, IEmployeeService employeeService) =>
//{
//    var createdEmployee = employeeService.AddEmployee(newEmployee);
//    return Results.Created($"/employees/{createdEmployee.Id}", createdEmployee);
//});

app.MapPost("/employees", (Employee newEmployee, IEmployeeService employeeService) =>
{
    if (!ValidationHelper.TryValidate(newEmployee, out var validationResults))
    {
        return Results.BadRequest(validationResults);
    }
    var createdEmployee = employeeService.AddEmployee(newEmployee);
    return Results.Created($"/employees/{createdEmployee.Id}", createdEmployee);
});

//app.MapPost("/employees", (Employee newEmployee) =>
//{
//    newEmployee.Id = employeeList.Count > 0 ? employeeList.Max(emp => emp.Id) + 1 : 1;
//    employeeList.Add(newEmployee);
//    return Results.Created($"/employees/{newEmployee.Id}", newEmployee);
//});

//app.MapPut("/employees/{id}", (int id, Employee updatedEmployee, IEmployeeService employeeService) =>
//{
//    var employee = employeeService.UpdateEmployee(id, updatedEmployee);
//    return employee is not null ? Results.Ok(employee) : Results.NotFound();
//});


app.MapPut("/employees/{id}", (int id, Employee updatedEmployee, IEmployeeService employeeService) =>
{
    if (!ValidationHelper.TryValidate(updatedEmployee, out var validationResults))
    {
        return Results.BadRequest(validationResults);
    }
    var employee = employeeService.UpdateEmployee(id, updatedEmployee);
    return employee is not null ? Results.Ok(employee) : Results.NotFound();
});
//app.MapPut("/employees/{id}", (int id, Employee updatedEmployee) =>
//{
//    var employee = employeeList.FirstOrDefault(emp => emp.Id == id);
//    if (employee is null) return Results.NotFound();
//    employee.Name = updatedEmployee.Name;
//    employee.Position = updatedEmployee.Position;
//    employee.Salary = updatedEmployee.Salary;
//    return Results.Ok(employee);
//});

app.MapDelete("/employees/{id}", (int id, IEmployeeService employeeService) =>
{
    var result = employeeService.DeleteEmployee(id);
    return result ? Results.NoContent() : Results.NotFound();
});

//app.MapDelete("/employees/{id}", (int id, IEmployeeService employeeService) =>
//{
//    var result = employeeService.DeleteEmployee(id);
//    return result ? Results.NoContent() : Results.NotFound();
//});

//app.MapDelete("/employees/{id}", (int id) =>
//{
//    var employee = employeeList.FirstOrDefault(emp => emp.Id == id);
//    if (employee is null) return Results.NotFound();
//    employeeList.Remove(employee);
//    return Results.NoContent();
//});


//app.MapGet("/weatherforecast", () =>
//{
//    var forecast = Enumerable.Range(1, 5).Select(index =>
//        new WeatherForecast
//        (
//            DateOnly.FromDateTime(DateTime.Now.AddDays(index)),
//            Random.Shared.Next(-20, 55),
//            summaries[Random.Shared.Next(summaries.Length)]
//        ))
//        .ToArray();
//    return forecast;
////})
//.WithName("GetWeatherForecast")
//.WithOpenApi();

app.Run();

internal record WeatherForecast(DateOnly Date, int TemperatureC, string? Summary)
{
    public int TemperatureF => 32 + (int)(TemperatureC / 0.5556);
}
