﻿using System.ComponentModel.DataAnnotations;

namespace MinimalAPiTest
{
    public static class ValidationHelper
    {
        public static bool TryValidate<T>(T model, out List<ValidationResult> validationResults)
        {
            var validationContext = new ValidationContext(model, null, null);
            validationResults = new List<ValidationResult>();
            return Validator.TryValidateObject(model, validationContext, validationResults, true);
        }
    }
}
