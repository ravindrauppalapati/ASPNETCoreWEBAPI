
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Versioning;

namespace APIVersioning
{
    public class Program
    {
        public static void Main(string[] args)
        {
            var builder = WebApplication.CreateBuilder(args);

            // Add services to the container.

            builder.Services.AddControllers();
            // Learn more about configuring Swagger/OpenAPI at https://aka.ms/aspnetcore/swashbuckle
            builder.Services.AddEndpointsApiExplorer();
            builder.Services.AddSwaggerGen();

             builder.Services.AddApiVersioning(opts=>
             {
                 opts.DefaultApiVersion = new ApiVersion(1, 0);
                 opts.AssumeDefaultVersionWhenUnspecified =true;
                 opts.ReportApiVersions = true;
                 // opts.ApiVersionReader = new QueryStringApiVersionReader("version");
                 //opts.ApiVersionReader = new UrlSegmentApiVersionReader();
                 // opts.ApiVersionReader = new HeaderApiVersionReader("X-API-Version");
                 opts.ApiVersionReader = new MediaTypeApiVersionReader();
             });
            var app = builder.Build();

            // Configure the HTTP request pipeline.
            if (app.Environment.IsDevelopment())
            {
                app.UseSwagger();
                app.UseSwaggerUI();
            }

            app.UseHttpsRedirection();

            app.UseAuthorization();


            app.MapControllers();

            app.Run();
        }
    }
}
