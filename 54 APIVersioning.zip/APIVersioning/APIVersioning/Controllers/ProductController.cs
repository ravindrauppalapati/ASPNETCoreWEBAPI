﻿using APIVersioning.Models;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;

namespace APIVersioning.Controllers
{ 
    [ApiController]
    //[Route("api/v{version:apiVersion}/product")]
    [Route("api/[controller]")]
    public class ProductController : ControllerBase
    {
        [HttpGet]
        [ApiVersion("1.0")]
        public IEnumerable<Product> GetV1()
        {
            return new List<Product>
            {
                new Product { Id = 1, Name = "Apple", Price = 1.50, Category = "Fruit" },
                new Product { Id = 2, Name = "Bread", Price = 2.25, Category = "Bakery" }
            };
        }

        [HttpGet]
        [ApiVersion("1.0")]
        [Route("{Id}")]
        public Product GetByIdV1(int Id)
        {
            return new Product { Id = Id, Name = "Apple", Price = 1.50, Category = "Fruit" };
        }

        [HttpGet]
        [ApiVersion("2.0")]
        public IEnumerable<Product> GetV2()
        {
            return new List<Product>
            {
                new Product { Id = 1, Name = "Apple", Price = 1.50, Category = "Fruit" },
                new Product { Id = 2, Name = "Bread", Price = 2.25, Category = "Bakery" },
                new Product { Id = 3, Name = "Carrot", Price = 0.75, Category = "Vegetable" }
            };
        }
    }
}
