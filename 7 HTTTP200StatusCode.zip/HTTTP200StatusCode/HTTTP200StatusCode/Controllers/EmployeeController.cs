﻿using HTTTP200StatusCode.Models;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;

namespace HTTTP200StatusCode.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class EmployeeController : ControllerBase
    {
        public List<Employee> employees = new List<Employee>()
        {
            new Employee(){Id=1,Name="AAA",Gender="Male",PhoneNo="1234567890",Address="GTR" },
            new Employee(){Id=2,Name="BBB",Gender="FeMale",PhoneNo="1234567891",Address="Hyd" },
            new Employee(){Id=3,Name="CCC",Gender="Male",PhoneNo="1234567892",Address="VJW" },
            new Employee(){Id=4,Name="DDD",Gender="FeMale",PhoneNo="1234567893",Address="VZG" },
            new Employee(){Id=5,Name="EEE",Gender="Male",PhoneNo="1234567894",Address="ONG" },
        };

        //[HttpGet]
        //public ActionResult<List<Employee>> GetEmployee()
        //{   
        //    return StatusCode(200,employees);
        //}

        [HttpGet]
        public ActionResult<Employee> GetEmployeeById(int Id)
        {
            var emp = employees.Where(x => x.Id == Id);
            return StatusCode(200, emp);
        }

        [HttpPost]
        public ActionResult<Employee> CreateEmployee(Employee employee)
        {
            var emp = employees.Where(x => x.Id == employee.Id).FirstOrDefault();
            if (emp == null)
            {
                employee.Id = employees.Count() + 1;
                employees.Add(employee);
                return CreatedAtAction(nameof(GetEmployeeById), new { Id = employee.Id }, employee);
            }
            else 
                return Ok(employee);
        }
    }
}
