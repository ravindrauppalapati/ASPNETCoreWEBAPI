﻿using AutoMapper;
using AutoMapper_Pre_Post_Conditonal_Mapping.DTOs;
using AutoMapper_Pre_Post_Conditonal_Mapping.Models;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;

namespace AutoMapper_Pre_Post_Conditonal_Mapping.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class UserController : ControllerBase
    {
        private readonly IMapper _mapper;
        public UserController(IMapper mapper)
        {
            _mapper = mapper;
        }
        [HttpPost]
        public IActionResult CreateUser([FromBody] UserDTO userDTO)
        {
            var user = _mapper.Map<User>(userDTO); 
            return Ok(user);
        }
    }
}
