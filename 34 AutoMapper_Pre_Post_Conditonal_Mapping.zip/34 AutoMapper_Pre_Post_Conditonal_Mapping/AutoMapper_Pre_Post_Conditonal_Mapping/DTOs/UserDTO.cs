﻿namespace AutoMapper_Pre_Post_Conditonal_Mapping.DTOs
{
    public class UserDTO
    {
        public string UserName { get; set; }
        public string Email { get; set; }
    }
}
