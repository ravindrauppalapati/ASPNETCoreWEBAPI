﻿using AutoMapper;
using AutoMapper_Pre_Post_Conditonal_Mapping.DTOs;
using AutoMapper_Pre_Post_Conditonal_Mapping.Models;

namespace AutoMapper_Pre_Post_Conditonal_Mapping.Services
{
    public class MappingProfile : Profile
    {
        public MappingProfile()
        {
            CreateMap<UserDTO,User>()
                .ForMember(dest => dest.Email,act => act.Condition(src => string.IsNullOrEmpty(src.Email)))
                .ForMember(dest => dest.UserName, act => act.PreCondition(src => !string.IsNullOrEmpty(src.UserName)))
                .AfterMap((src,dest) => Console.WriteLine($"Mapped {src.UserName} to {dest.UserName}"));
        }
    }
}
