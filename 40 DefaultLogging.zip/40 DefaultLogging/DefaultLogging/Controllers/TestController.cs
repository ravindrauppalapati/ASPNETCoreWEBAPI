﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;

namespace DefaultLogging.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class TestController : ControllerBase
    {
        private readonly ILogger<TestController> _logger;
        public TestController(ILogger<TestController> logger)
        {
            _logger = logger; 
        }

        [HttpGet]
        public IActionResult Get()
        {
            //_logger.LogTrace("trace : Entered into Get Method");
            //try
            //{
            //    _logger.LogDebug("Debug : Started processing Get Method");

            //    _logger.LogInformation("Information : Performing some Operations");
            //    if (DateTime.Now.Microsecond % 2 == 0)
            //    {
            //        _logger.LogWarning("Warning : Unexpected issue");
            //    }
            //    else
            //    {
            //        throw new InvalidOperationException("Error Occurred");
            //    }
            //    _logger.LogInformation("Information : Successfully Operation Completed");

            //    _logger.Log(LogLevel.Information, "Get Method Execution Succeeded");

            //    return Ok("Success");
            //}
            //catch (Exception ex)
            //{
            //    _logger.LogError(ex, "An Error Occurred");
            //    _logger.LogCritical(ex, "This error is Critical");

            //    return StatusCode(500);
            //}
            //finally
            //{
            //    _logger.LogTrace("Trace : Exit");
            //}

            _logger.LogTrace("Trace");
            _logger.LogDebug("Debug");
            _logger.LogInformation("Information");
            _logger.LogWarning("Warning");
            _logger.LogError("Error");
            _logger.LogCritical("Critical");
            return Ok("Success");
        }
    }
}
