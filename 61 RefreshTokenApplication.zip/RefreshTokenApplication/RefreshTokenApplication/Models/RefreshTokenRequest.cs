﻿using System.ComponentModel.DataAnnotations;

namespace RefreshTokenApplication.Models
{
    public class RefreshTokenRequest
    {
        [Required]
        public string RefreshToken { get; set; }
    }
}
