﻿using Microsoft.EntityFrameworkCore;
using RefreshTokenApplication.Models;
namespace RefreshTokenApplication.Data
{
    public class AuthDbContext : DbContext
    {
        public AuthDbContext(DbContextOptions<AuthDbContext> opts):base(opts)  
        {
            
        }
        public DbSet<RefreshToken> RefreshTokens { get; set; }
    }
}
