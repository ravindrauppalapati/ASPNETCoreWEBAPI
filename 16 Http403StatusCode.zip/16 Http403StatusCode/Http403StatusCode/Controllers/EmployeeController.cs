﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;

namespace Http403StatusCode.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class EmployeeController : ControllerBase
    {
        //[HttpGet]
        //public IActionResult GetResource()
        //{
        //    bool hasPermission = false;
        //    if (!hasPermission)
        //    {
        //        return StatusCode(StatusCodes.Status403Forbidden);
        //    }
        //    return Ok("Resource Content Here");
        //}
        //===============================================================
        //[HttpGet]
        //public IActionResult GetResource()
        //{
        //    bool hasPermission = false;
        //    if (!hasPermission)
        //    {
        //        var errorResponse = new
        //        {
        //            StatusCode = StatusCodes.Status403Forbidden,
        //            Message = "Access denied. You do not have permission to access this resource."
        //        };
        //        return StatusCode(StatusCodes.Status403Forbidden, errorResponse);
        //    }
        //    return Ok("Resource Content Here");
        //}
        //=======================================================
        [HttpGet]
        public IActionResult GetResource()
        {
            return Ok("Resource Content Here");
        }
    }
}
 
