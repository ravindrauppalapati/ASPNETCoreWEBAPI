﻿using System.Text.Json;

namespace Http403StatusCode.Services
{
    public class CustomAuthorizationMiddleware
    {
        private readonly RequestDelegate _next; 
        public CustomAuthorizationMiddleware(RequestDelegate next)
        {
            _next = next;  
        } 
        public async Task Invoke(HttpContext context)
        { 
            bool isAuthorized = CheckUserAuthorization(context); 
            if (!isAuthorized)
            { 
                context.Response.StatusCode = StatusCodes.Status403Forbidden; 
                context.Response.ContentType = "application/json"; 
                var customResponse = new
                {
                    Code = 403,  
                    Message = "Access is denied due to insufficient permissions."  
                }; 
                var responseJson = JsonSerializer.Serialize(customResponse); 
                await context.Response.WriteAsync(responseJson);
                return;  
            } 
            await _next(context);
        } 
        private bool CheckUserAuthorization(HttpContext context)
        { 
            return false;
        }
    }
}
