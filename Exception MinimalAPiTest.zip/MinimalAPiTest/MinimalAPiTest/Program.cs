using Microsoft.AspNetCore.Mvc;
using MinimalAPiTest;

var builder = WebApplication.CreateBuilder(args);
 
builder.Services.AddEndpointsApiExplorer();
builder.Services.AddSwaggerGen();
builder.Services.AddSingleton<IEmployeeService,EmployeeService>();
builder.Logging.ClearProviders();
builder.Logging.AddConsole();
builder.Logging.AddDebug();

var app = builder.Build();

// Configure the HTTP request pipeline.
if (app.Environment.IsDevelopment())
{
    app.UseSwagger();
    app.UseSwaggerUI();
}

app.UseHttpsRedirection();

app.UseMiddleware<ErrorHandlerMiddleware>();

#region Custom Exception Middleware
//app.MapGet("/employees", (IEmployeeService employeeService) => employeeService.GetAllEmployees());

//app.MapGet("/employees/{id}", (int id, IEmployeeService employeeService) =>
//{
//    int x = 10, y = 0;
//    int c = x / y;
//    var employee = employeeService.GetEmployeeById(id);
//    return employee is not null ? Results.Ok(employee) : Results.NotFound();
//}); 

//app.MapPost("/employees", (Employee newEmployee, IEmployeeService employeeService) =>
//{
//    if (!ValidationHelper.TryValidate(newEmployee, out var validationResults))
//    {
//        return Results.BadRequest(validationResults);
//    }
//    var createdEmployee = employeeService.AddEmployee(newEmployee);
//    return Results.Created($"/employees/{createdEmployee.Id}", createdEmployee);
//}); 

//app.MapPut("/employees/{id}", (int id, Employee updatedEmployee, IEmployeeService employeeService) =>
//{
//    if (!ValidationHelper.TryValidate(updatedEmployee, out var validationResults))
//    {
//        return Results.BadRequest(validationResults);
//    }
//    var employee = employeeService.UpdateEmployee(id, updatedEmployee);
//    return employee is not null ? Results.Ok(employee) : Results.NotFound();
//}); 

//app.MapDelete("/employees/{id}", (int id, IEmployeeService employeeService) =>
//{
//    var result = employeeService.DeleteEmployee(id);
//    return result ? Results.NoContent() : Results.NotFound();
//});
#endregion 

#region Try Catch
//======================  Try Catch =============================================
//app.MapGet("/employees", (IEmployeeService employeeService) =>
//{
//    try
//    {
//        return Results.Ok(employeeService.GetAllEmployees());
//    }
//    catch (Exception ex)
//    {
//        return Results.Problem(ex.Message);
//    }
//});


//app.MapGet("/employees/{id}", (int id, IEmployeeService employeeService) =>
//{
//    try
//    {
//        int x = 10, y = 0;
//        int result = x / y;
//        var employee = employeeService.GetEmployeeById(id);
//        return employee is not null ? Results.Ok(employee) : Results.NotFound();
//    }
//    catch (Exception ex)
//    {
//        return Results.Problem(ex.Message);
//    }
//});


//app.MapPost("/employees", (Employee newEmployee, IEmployeeService employeeService) =>
//{
//    try
//    {
//        if (!ValidationHelper.TryValidate(newEmployee, out var validationResults))
//        {
//            return Results.BadRequest(validationResults);
//        }
//        var createdEmployee = employeeService.AddEmployee(newEmployee);
//        return Results.Created($"/employees/{createdEmployee.Id}", createdEmployee);
//    }
//    catch (Exception ex)
//    {
//        return Results.Problem(ex.Message);
//    }
//});


//app.MapPut("/employees/{id}", (int id, Employee updatedEmployee, IEmployeeService employeeService) =>
//{
//    try
//    {
//        if (!ValidationHelper.TryValidate(updatedEmployee, out var validationResults))
//        {
//            return Results.BadRequest(validationResults);
//        }
//        var employee = employeeService.UpdateEmployee(id, updatedEmployee);
//        return employee is not null ? Results.Ok(employee) : Results.NotFound();
//    }
//    catch (Exception ex)
//    {
//        return Results.Problem(ex.Message);
//    }
//});


//app.MapDelete("/employees/{id}", (int id, IEmployeeService employeeService) =>
//{
//    try
//    {
//        var result = employeeService.DeleteEmployee(id);
//        return result ? Results.NoContent() : Results.NotFound();
//    }
//    catch (Exception ex)
//    {
//        return Results.Problem(ex.Message);
//    }
//});
#endregion

//==================================Logging =====================================
app.MapGet("/employees", (IEmployeeService employeeService, ILogger<Program> logger) =>
{
    try
    {
        logger.LogInformation("Retrieving all employees");
        return Results.Ok(employeeService.GetAllEmployees());
    }
    catch (Exception ex)
    {
        logger.LogError(ex, "An error occurred while retrieving all employees");
        return Results.Problem(ex.Message);
    }
});


app.MapGet("/employees/{id}", (int id, IEmployeeService employeeService, ILogger<Program> logger) =>
{
    try
    {
        logger.LogInformation("Retrieving employee with ID {Id}", id);
        var employee = employeeService.GetEmployeeById(id);
        if (employee == null)
        {
            logger.LogWarning("Employee with ID {Id} not found", id);
            return Results.NotFound(new { Message = $"Employee with ID {id} not found" });
        }
        return Results.Ok(employee);
    }
    catch (Exception ex)
    {
        logger.LogError(ex, "An error occurred while retrieving employee with ID {Id}", id);
        var problemDetails = new ProblemDetails
        {
            Status = 500,
            Title = "An unexpected error occurred.",
            Detail = ex.Message,
            Instance = $"/employees/{id}"
        };
        return Results.Problem(ex.Message);
    }
});


app.MapPost("/employees", (Employee newEmployee, IEmployeeService employeeService, ILogger<Program> logger) =>
{
    try
    {
        if (!ValidationHelper.TryValidate(newEmployee, out var validationResults))
        {
            return Results.BadRequest(validationResults);
        }
        logger.LogInformation("Creating a new employee");
        var createdEmployee = employeeService.AddEmployee(newEmployee);
        return Results.Created($"/employees/{createdEmployee.Id}", createdEmployee);
    }
    catch (Exception ex)
    {
        logger.LogError(ex, "An error occurred while creating a new employee");
        return Results.Problem(ex.Message);
    }
});


app.MapPut("/employees/{id}", (int id, Employee updatedEmployee, IEmployeeService employeeService, ILogger<Program> logger) =>
{
    try
    {
        if (!ValidationHelper.TryValidate(updatedEmployee, out var validationResults))
        {
            return Results.BadRequest(validationResults);
        }
        logger.LogInformation("Updating employee with ID {Id}", id);
        var employee = employeeService.UpdateEmployee(id, updatedEmployee);
        if (employee == null)
        {
            logger.LogWarning("Employee with ID {Id} not found", id);
            return Results.NotFound(new { Message = $"Employee with ID {id} not found" });
        }
        return Results.Ok(employee);
    }
    catch (Exception ex)
    {
        logger.LogError(ex, "An error occurred while updating employee with ID {Id}", id);
        return Results.Problem(ex.Message);
    }
});


app.MapDelete("/employees/{id}", (int id, IEmployeeService employeeService, ILogger<Program> logger) =>
{
    try
    {
        logger.LogInformation("Deleting employee with ID {Id}", id);
        var result = employeeService.DeleteEmployee(id);
        if (!result)
        {
            logger.LogWarning("Employee with ID {Id} not found", id);
            return Results.NotFound(new { Message = $"Employee with ID {id} not found" });
        }
        return Results.NoContent();
    }
    catch (Exception ex)
    {
        logger.LogError(ex, "An error occurred while deleting employee with ID {Id}", id);
        return Results.Problem(ex.Message);
    }
});
app.Run();

internal record WeatherForecast(DateOnly Date, int TemperatureC, string? Summary)
{
    public int TemperatureF => 32 + (int)(TemperatureC / 0.5556);
}
