﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Caching.Distributed;
using RedisCACHE.Models;
using System.Text.Json;
using System.Text;

namespace RedisCACHE.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class ProductController : ControllerBase
    {
        //private readonly AppDbContext _context;
        //public ProductController(AppDbContext context)
        //{
        //    _context = context;
        //}
        //[HttpGet]
        //public async Task<IActionResult> GetAll()
        //{
        //    var products = await _context.Products.ToListAsync();
        //    return Ok(products);
        //}

        private readonly AppDbContext _context;
        private readonly IDistributedCache _cache;
        public ProductController(AppDbContext context, IDistributedCache cache)
        {
            _context = context;
            _cache = cache;
        }
        [HttpGet]
        public async Task<IActionResult> GetAll()
        {
            var cacheKey = "GET_ALL_PRODUCTS";

            List<Product> products;

            var cachedData = await _cache.GetAsync(cacheKey);
            if (cachedData != null)
            {
                var cachedDataString = Encoding.UTF8.GetString(cachedData);
                products = JsonSerializer.Deserialize<List<Product>>(cachedDataString) ?? new List<Product>();
            }
            else
            {
                products = await _context.Products.ToListAsync();
                var cachedDataString = JsonSerializer.Serialize(products);
                var newDataToCache = Encoding.UTF8.GetBytes(cachedDataString);
               
                var options = new DistributedCacheEntryOptions()
                    .SetAbsoluteExpiration(DateTime.Now.AddMinutes(2))
                    .SetSlidingExpiration(TimeSpan.FromMinutes(1));
                
                await _cache.SetAsync(cacheKey, newDataToCache, options);
            }
            return Ok(products);
        }
    }
}
