﻿using CORSServer.Models;

namespace CORSServer.Repo
{
    public class UserRepository
    {
        private static List<User> _users = new List<User>
        {
            new User { Id = 1, FullName = "John Doe", Email = "john.doe@example.com", Position = "Developer" },
            new User { Id = 2, FullName = "Jane Smith", Email = "jane.smith@example.com", Position = "Manager" },
            new User { Id = 3, FullName = "Sara Taylor", Email = "sara.taylor@example.com", Position = "Manager" },
            new User { Id = 4, FullName = "Pam Jordon", Email = "pam.jordon@example.com", Position = "Developer" }
        };
        public async Task<IEnumerable<User>> GetAllUsersAsync()
        {
            await Task.Delay(TimeSpan.FromMilliseconds(1));
            return _users;
        }
        public async Task<User?> GetUserByIdAsync(int id)
        {
            await Task.Delay(TimeSpan.FromMilliseconds(1));
            return _users.FirstOrDefault(u => u.Id == id);
        }
        public async Task AddUserAsync(User user)
        {
            await Task.Delay(TimeSpan.FromMilliseconds(1));
            user.Id = _users.Max(u => u.Id) + 1;
            _users.Add(user);
        }
        public async Task UpdateUserAsync(User user)
        {
            await Task.Delay(TimeSpan.FromMilliseconds(1));
            var existingUser = _users.FirstOrDefault(u => u.Id == user.Id);
            if (existingUser != null)
            {
                existingUser.FullName = user.FullName;
                existingUser.Email = user.Email;
                existingUser.Position = user.Position;
            }
        }
        public async Task DeleteUserAsync(int id)
        {
            await Task.Delay(TimeSpan.FromMilliseconds(1));
            var user = _users.FirstOrDefault(u => u.Id == id);
            if (user != null)
            {
                _users.Remove(user);
            }
        }
    }
}
