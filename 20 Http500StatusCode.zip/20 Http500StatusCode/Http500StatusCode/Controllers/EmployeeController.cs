﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;

namespace Http500StatusCode.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class EmployeeController : ControllerBase
    {
        //[HttpGet]
        //public IActionResult GetEmployee()
        //{ 
        //    int x = 10, y = 0;
        //    int z = x / y; 
        //    return Ok();
        //}
        //=========================================================
        //[HttpGet]
        //public IActionResult GetEmployee()
        //{
        //    try
        //    { 
        //        int x = 10, y = 0;
        //        int z = x / y;  
        //        return Ok();
        //    }
        //    catch (Exception ex)
        //    { 
        //        var customResponse = new
        //        {
        //            Code = 500,
        //            Message = "Internal Server Error", 
        //            ErrorMessage = ex.Message
        //        };
        //        return StatusCode(StatusCodes.Status500InternalServerError, customResponse);
        //    }
        //}
        //================================================================
        //[HttpGet]
        //public IActionResult GetEmployee()
        //{
        //    try
        //    { 
        //        int x = 10, y = 0;
        //        int z = x / y;  
        //        return Ok();
        //    }
        //    catch (Exception ex)
        //    {  
        //        var customResponse = new
        //        {
        //            Code = 500,
        //            Message = "Internal Server Error", 
        //            ErrorMessage = ex.Message
        //        };
        //        return new ObjectResult(customResponse)
        //        {
        //            StatusCode = StatusCodes.Status500InternalServerError
        //        };

        //    }
        //}
        //=================================================================
        //[HttpGet]
        //public IActionResult GetEmployee()
        //{ 
        //    int x = 10, y = 0;
        //    int z = x / y;  
        //    return Ok();
        //}
    }
}
