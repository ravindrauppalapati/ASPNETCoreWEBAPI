﻿using System.Text.Json;

namespace Http500StatusCode.Services
{
    public class ErrorHandlingMiddleware
    {
        private readonly RequestDelegate _next; 
        public ErrorHandlingMiddleware(RequestDelegate next)
        {
            _next = next;
        } 
        public async Task Invoke(HttpContext context)
        {
            try
            { 
                await _next(context);
            }
            catch (Exception ex)
            { 
                context.Response.StatusCode = StatusCodes.Status500InternalServerError; 
                context.Response.ContentType = "application/json"; 
                var customErrorResponse = new
                {
                    Code = 500,
                    Message = "Internal Server Error Occurred",
                    ExceptionDetails = ex.Message  
                }; 
                var responseJson = JsonSerializer.Serialize(customErrorResponse); 
                await context.Response.WriteAsync(responseJson);
            }
        }
    }
}
