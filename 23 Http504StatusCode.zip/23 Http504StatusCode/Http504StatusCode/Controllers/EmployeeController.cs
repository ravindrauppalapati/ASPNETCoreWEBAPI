﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using System.Text.Json;

namespace Http504StatusCode.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class EmployeeController : ControllerBase
    {
        //private readonly HttpClient _httpClient; 
        //public EmployeeController(HttpClient httpClient)
        //{ 
        //    _httpClient = httpClient;
        //} 
        //[HttpGet]
        //public async Task<IActionResult> GetResource()
        //{ 
        //    var requestUrl = "https://httpstat.us/504";
        //    try
        //    { 
        //        var response = await _httpClient.GetAsync(requestUrl); 
        //        if (response.StatusCode == System.Net.HttpStatusCode.GatewayTimeout)
        //        { 
        //            var customResponse = new
        //            {
        //                Code = 504,
        //                Message = "The request timed out waiting for an external service.",
        //            }; 
        //            var responseJson = JsonSerializer.Serialize(customResponse); 
        //            return StatusCode(504, responseJson);
        //        } 
        //        if (response.IsSuccessStatusCode)
        //        { 
        //            var content = await response.Content.ReadAsStringAsync(); 
        //            return Ok(content);
        //        }
        //        else
        //        { 
        //            return StatusCode((int)response.StatusCode, "Failed to retrieve the resource.");
        //        }
        //    }
        //    catch (Exception ex)  
        //    { 
        //        var customResponse = new
        //        {
        //            Code = 500,
        //            Message = $"Internal Server Error: {ex.Message}",
        //        }; 
        //        var responseJson = JsonSerializer.Serialize(customResponse); 
        //        return StatusCode(500, responseJson);
        //    }
        //}
        //==========================================================================
        //private readonly HttpClient _httpClient; 
        //public EmployeeController(HttpClient httpClient)
        //{ 
        //    _httpClient = httpClient;
        //} 
        //[HttpGet]
        //public async Task<IActionResult> GetResource()
        //{ 
        //    var requestUrl = "https://httpstat.us/504"; 
        //    var response = await _httpClient.GetAsync(requestUrl); 
        //    response.EnsureSuccessStatusCode(); 
        //    var content = await response.Content.ReadAsStringAsync(); 
        //    return Ok(content);
        //}
    }
}
