﻿using System.Text.Json;

namespace Http504StatusCode.Models
{
    public class GatewayTimeoutMiddleware
    {
        private readonly RequestDelegate _next; 
        public GatewayTimeoutMiddleware(RequestDelegate next)
        { 
            _next = next;
        } 
        public async Task Invoke(HttpContext context)
        {
            try
            { 
                await _next(context);
            }
            catch (HttpRequestException ex) when (ex.StatusCode == System.Net.HttpStatusCode.GatewayTimeout)
            { 
                if (!context.Response.HasStarted)
                { 
                    context.Response.Clear();  
                    context.Response.StatusCode = StatusCodes.Status504GatewayTimeout;  
                    context.Response.ContentType = "application/json";   
                    var customResponse = new
                    {
                        Code = 504,
                        Message = "Server did not receive a timely response from an upstream server."
                    }; 
                    var responseJson = JsonSerializer.Serialize(customResponse); 
                    await context.Response.WriteAsync(responseJson);
                }
            }
            catch (Exception ex)
            { 
                if (!context.Response.HasStarted)
                { 
                    context.Response.Clear();  
                    context.Response.StatusCode = StatusCodes.Status500InternalServerError;  
                    context.Response.ContentType = "application/json";  
                    var customResponse = new
                    {
                        Code = 500,
                        Message = "Internal Server Error",
                        Details = ex.Message  
                    }; 
                    var responseJson = JsonSerializer.Serialize(customResponse); 
                    await context.Response.WriteAsync(responseJson);
                }
            }
        }
    }
}
