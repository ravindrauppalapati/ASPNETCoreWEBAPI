﻿using AutoMapper;
using AutoMapperIgnore.DTOs;
using AutoMapperIgnore.Models;

namespace AutoMapperIgnore.Services
{
    public class MappingProfile : Profile
    {
        public MappingProfile()
        {
            CreateMap<User, UserDTO>()
          .ForMember(dest => dest.Password, opt => opt.Ignore())
          .ForMember(dest => dest.SecurityToken, opt => opt.Ignore());
        }
    }
}
