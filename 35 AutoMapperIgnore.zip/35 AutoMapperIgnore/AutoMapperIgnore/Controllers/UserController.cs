﻿using AutoMapper;
using AutoMapperIgnore.DTOs;
using AutoMapperIgnore.Models;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;

namespace AutoMapperIgnore.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class UserController : ControllerBase
    {
        private readonly IMapper _mapper;
        public UserController(IMapper mapper)
        {
            _mapper = mapper;
        }
        [HttpGet("{Id}")]
        public IActionResult GetUser(int Id)
        {
            var user = new User()
            {
                Id = Id,
                Username = "Test",
                Password = "123@ABC",
                SecurityToken = Guid.NewGuid().ToString(),
            };
            var userDTO = _mapper.Map<UserDTO>(user);

            return Ok(userDTO);
        }
    }
}
