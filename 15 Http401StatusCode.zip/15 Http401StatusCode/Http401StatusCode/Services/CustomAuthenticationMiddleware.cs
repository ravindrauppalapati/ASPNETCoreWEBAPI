﻿namespace Http401StatusCode.Services
{
    public class CustomAuthenticationMiddleware
    {
        private readonly RequestDelegate _next; 
        public CustomAuthenticationMiddleware(RequestDelegate next)
        {
            _next = next;  
        } 
        public async Task InvokeAsync(HttpContext context)
        { 
            bool isAuthorized = CheckAuthorization(context);  
            if (!isAuthorized)  
            {
                context.Response.StatusCode = StatusCodes.Status401Unauthorized;  
                context.Response.ContentType = "application/json";   
                var customResponse = new
                {
                    status = 401, 
                    message = "Unauthorized. Please Provide Valid Credentials" 
                }; 
                await context.Response.WriteAsync(System.Text.Json.JsonSerializer.Serialize(customResponse));
                return;  
            } 
            await _next(context);
        }
     
        private bool CheckAuthorization(HttpContext context)
        { 
            return false;  
        }
    }
}
