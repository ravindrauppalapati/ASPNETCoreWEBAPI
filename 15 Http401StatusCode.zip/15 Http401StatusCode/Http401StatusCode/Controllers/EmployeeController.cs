﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;

namespace Http401StatusCode.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class EmployeeController : ControllerBase
    {
        //[HttpGet]
        //public IActionResult SecureResource()
        //{
        //    bool isAuthenticated = false;
        //    if (!isAuthenticated)
        //    {
        //        return Unauthorized();
        //    }
        //    return Ok("Authenticated and Authorized Access.");
        //}

        //========================================================
        //[HttpGet]
        //public IActionResult SecureResource()
        //{
        //    bool isAuthenticated = false;
        //    if (!isAuthenticated)
        //    {
        //        return Unauthorized(new { message = "Access denied. Please provide valid credentials." });
        //    }
        //    return Ok("Authenticated and Authorized Access.");
        //}
        //====================================================================
        //[HttpGet]
        //public IActionResult SecureResource()
        //{
        //    bool isAuthenticated = false;
        //    if (!isAuthenticated)
        //    {
        //        var errorResponse = new
        //        {
        //            StatusCode = StatusCodes.Status401Unauthorized,
        //            Message = "Access denied. Please provide valid credentials."
        //        };
        //        return StatusCode(StatusCodes.Status401Unauthorized, errorResponse);
        //    }
        //    return Ok("Authenticated and Authorized Access.");
        //}
        //==========================================================================
        //Middleware to Handle 401 Unauthorized Error
        [HttpGet]
        public IActionResult SecureResource()
        {
            return Ok("Authenticated and Authorized Access.");
        }
    }
}
