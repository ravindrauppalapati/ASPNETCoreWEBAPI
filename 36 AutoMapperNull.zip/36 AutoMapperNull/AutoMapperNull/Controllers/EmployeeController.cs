﻿using AutoMapper;
using AutoMapperNull.DTOs;
using AutoMapperNull.Models;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;

namespace AutoMapperNull.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class EmployeeController : ControllerBase
    {
        private readonly IMapper _mapper;
        public List<Employee> listEmployees = new List<Employee>()
        {
            new Employee(){Id = 1, Name="Ravindra", Department="IT", Address = "GTR",CreatedBy=null, CreatedOn=null },
            new Employee(){Id = 2, Name="Narendra", Department="HR", Address = null,CreatedBy=null, CreatedOn=DateTime.Now },
            new Employee(){Id = 3, Name="Nishanth", Department="HR", Address = null,CreatedBy="Admin", CreatedOn=null  }
        };
        public EmployeeController(IMapper mapper)
        {
            _mapper = mapper;
        }
        [HttpGet("{Id}")]
        public ActionResult<EmployeeDTO> GetEmployee(int Id)
        {
            var employee = listEmployees.FirstOrDefault(emp => emp.Id == Id);
            if (employee == null)
            {
                return NotFound("Employee Not Found");
            }
            var employeeDTO = _mapper.Map<EmployeeDTO>(employee);
            return Ok(employeeDTO);
        }
    }
}
