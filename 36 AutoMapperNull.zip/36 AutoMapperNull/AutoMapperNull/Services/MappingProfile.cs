﻿using AutoMapper;
using AutoMapperNull.DTOs;
using AutoMapperNull.Models;

namespace AutoMapperNull.Services
{
    public class MappingProfile : Profile
    {
        public MappingProfile()
        {
            CreateMap<Employee, EmployeeDTO>() 
                .ForMember(dest => dest.Address, act => act.NullSubstitute("N/A")) 
                .ForMember(dest => dest.CreatedBy, act => act.NullSubstitute("System")) 
                .ForMember(dest => dest.CreatedOn, act => act.NullSubstitute(DateTime.Now));
        }
    }
}
