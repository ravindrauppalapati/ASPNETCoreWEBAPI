﻿using Microsoft.AspNetCore.Mvc;
using System.Text.Json;

namespace Http501StatusCode.Services
{
    public class NotImplementedResult : IActionResult
    { 
        private readonly object _detail; 
        public NotImplementedResult(object detail)
        {
            _detail = detail; 
        } 
        public async Task ExecuteResultAsync(ActionContext context)
        { 
            var json = JsonSerializer.Serialize(_detail); 
            context.HttpContext.Response.ContentType = "application/json"; 
            context.HttpContext.Response.StatusCode = StatusCodes.Status501NotImplemented; 
            await context.HttpContext.Response.WriteAsync(json);
        }
    }
}
