﻿using System.Security.Cryptography;

namespace SecretKeyApp
{
    internal class Program
    {
        static void Main(string[] args)
        {
            var randomBytes = new byte[32];
            using (var rng = RandomNumberGenerator.Create())
            {
                rng.GetBytes(randomBytes);
            }
            Console.WriteLine(Convert.ToBase64String(randomBytes));
            Console.ReadKey();
        }
    }
}
