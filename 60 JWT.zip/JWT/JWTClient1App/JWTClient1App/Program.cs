﻿using System.Net.Http.Headers;
using System.Net;
using System.Text.Json;
using System.Text;

namespace JWTClient1App
{
    internal class Program
    {
        private static readonly HttpClient httpClient = new HttpClient();

        private static readonly string baseUrl = "https://localhost:7127/api/users";
        static async Task Main(string[] args)
        {
            try
            {
                var token = await AuthenticateAndGetToken();
                Console.WriteLine("Token received: " + token);
                Console.WriteLine(await GetUser(token, 1));
                Console.WriteLine(await CreateUser(token, new User { Id = 4, Username = "newuser", Email = "newuser@example.com" }));
                Console.WriteLine(await UpdateUser(token, 4, new User { Id = 4, Username = "updatedUser", Email = "updateduser@example.com" }));
                Console.WriteLine(await DeleteUser(token, 4));
                Console.ReadKey();
            }
            catch (Exception ex)
            {
                Console.WriteLine("Error: " + ex.Message);
            }
        }
        static async Task<string> AuthenticateAndGetToken()
        {
            var loginUrl = "https://localhost:7070/api/Auth/Login";
            var loginRequestBody = new { Username = "admin", Password = "password" };
            var requestContent = new StringContent(JsonSerializer.Serialize(loginRequestBody), Encoding.UTF8, "application/json");
            var response = await httpClient.PostAsync(loginUrl, requestContent);
            if (!response.IsSuccessStatusCode)
            {
                var errorContent = await response.Content.ReadAsStringAsync();
                return $"Login failed: {errorContent}";
            }
            var loginResponseContent = await response.Content.ReadAsStringAsync();
            var tokenObject = JsonSerializer.Deserialize<JsonElement>(loginResponseContent);
            return tokenObject.GetProperty("Token").GetString();
        }
        static async Task<string> GetUser(string token, int userId)
        {
            httpClient.DefaultRequestHeaders.Authorization = new AuthenticationHeaderValue("Bearer", token);
            var response = await httpClient.GetAsync(baseUrl + $"/{userId}");
            return await ProcessResponse(response, "Get User");
        }
        static async Task<string> CreateUser(string token, User user)
        {
            httpClient.DefaultRequestHeaders.Authorization = new AuthenticationHeaderValue("Bearer", token);
            var response = await httpClient.PostAsync(baseUrl,
                new StringContent(JsonSerializer.Serialize(user), Encoding.UTF8, "application/json"));
            return await ProcessResponse(response, "Create User");
        }
        static async Task<string> UpdateUser(string token, int userId, User user)
        {
            httpClient.DefaultRequestHeaders.Authorization = new AuthenticationHeaderValue("Bearer", token);
            var response = await httpClient.PutAsync(baseUrl + $"/{userId}",
                new StringContent(JsonSerializer.Serialize(user), Encoding.UTF8, "application/json"));
            return await ProcessResponse(response, "Update User");
        }
        static async Task<string> DeleteUser(string token, int userId)
        {
            httpClient.DefaultRequestHeaders.Authorization = new AuthenticationHeaderValue("Bearer", token);
            var response = await httpClient.DeleteAsync(baseUrl + $"/{userId}");
            return await ProcessResponse(response, "Delete User");
        }
        private static async Task<string> ProcessResponse(HttpResponseMessage response, string action)
        {
            var responseBody = await response.Content.ReadAsStringAsync();
            if (response.IsSuccessStatusCode)
            {
                return $"{action} succeeded: {responseBody}";
            }
            switch (response.StatusCode)
            {
                case HttpStatusCode.Unauthorized:
                    return $"{action} Failed: Unauthorized - Token may be invalid or expired";
                case HttpStatusCode.Forbidden:
                    return $"{action} Failed: Forbidden - Insufficient permissions";
                default:
                    return $"{action} Failed: {response.StatusCode} - {responseBody}";
            }
        }
    }

    public class User
    {
        public int Id { get; set; }
        public string Username { get; set; }
        public string Email { get; set; }
    }
}
