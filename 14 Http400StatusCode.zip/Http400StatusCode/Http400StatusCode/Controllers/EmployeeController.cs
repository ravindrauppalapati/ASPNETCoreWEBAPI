﻿using Http400StatusCode.Models;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;

namespace Http400StatusCode.Controllers
{
    [Route("api/[controller]")]
    // [ApiController]
    public class EmployeeController : ControllerBase
    {
        //Using BadRequest Method
        //[HttpPost]
        //public IActionResult CreateEmployee([FromBody] Employee employee)
        //{
        //    if (!ModelState.IsValid)
        //    {
        //        return BadRequest(ModelState);

        //    }
        //    return Ok();

        //}
        //========================================================================
        //How It’s Generated

        //[HttpPost]
        //public IActionResult CreateEmployee([FromBody] Employee employee)
        //{
        //    return Ok();
        //}
        //======================================================================
        //Returning BadRequestObjectResult Directly
        //[HttpPost]
        //public IActionResult CreateEmployee([FromBody] Employee employee)
        //{
        //    if (!ModelState.IsValid)
        //    {
        //        var errorResponse = new { error = "Invalid Request Data" };
        //        return new BadRequestObjectResult(errorResponse);
        //    }
        //    return Ok(); 

        //} 
        //==============================================================
        //Example to Understand Problem Details in ASP.NET Core Web API:
        //[HttpPost]
        //public IActionResult CreateEmployee([FromBody] Employee employee)
        //{
        //    if (!ModelState.IsValid)
        //    {
        //        var errors = ModelState
        //            .Where(e => e.Value?.Errors.Count > 0)
        //            .ToDictionary(
        //                kvp => kvp.Key,
        //                kvp => kvp.Value?.Errors.Select(e => e.ErrorMessage).ToArray()
        //            );
        //        var problemDetails = new ProblemDetails()
        //        {
        //            Title = "Validation Errors Occurred.",
        //            Detail = "See the errors property for details",
        //            Type = "https://tools.ietf.org/html/rfc7231#section-6.5.1",
        //            Status = StatusCodes.Status400BadRequest,
        //            Instance = HttpContext.Request.Path,
        //            Extensions = new Dictionary<string, object?>
        //            {
        //                { "Retry", "Please Retry After 30 Minutes" },
        //                { "errors", errors }
        //            }
        //        };

        //        return BadRequest(problemDetails);
        //    }
        //    return Ok();
        //}
        //=======================================================================
        //Using ValidationProblemDetails Object in ASP.NET Core Web API
        //[HttpPost]
        //public IActionResult CreateEmployee([FromBody] Employee employee)
        //{
        //    if (!ModelState.IsValid)
        //    {
        //        var problemDetails = new ValidationProblemDetails(ModelState)
        //        {
        //            Title = "Validation Errors Occurred.",
        //            Detail = "See the errors property for details",
        //            Type = "https://tools.ietf.org/html/rfc7231#section-6.5.1",
        //            Status = StatusCodes.Status400BadRequest,
        //            Instance = HttpContext.Request.Path,
        //        };

        //        return BadRequest(problemDetails);
        //    }
        //    return Ok();
        //}
        //========================================================================
        //Manually Returning 400 HTTP Responses in ASP.NET Core Web API

        //[HttpPost]
        //public IActionResult CreateEmployee([FromBody] Employee employee)
        //{
        //    if (!ModelState.IsValid)
        //    {
        //        Response.StatusCode = 400;
        //        return new ObjectResult(new { Error = "Invalid data provided" });
        //    }
        //    return Ok();
        //}
        //=======================================================================
    }
}
