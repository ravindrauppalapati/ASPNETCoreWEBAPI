﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;

namespace Http302StatusCode.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class EmployeeController : ControllerBase
    {
        [HttpGet]
        [Route("OldEndPoint")]
        public IActionResult getfromOldEndPoint()
        {
            string? newUrl = Url.Action("getNewEndPoint", "Employee");
            if (newUrl == null)
            {
                return BadRequest("Unable to generate location");
            }

            Response.StatusCode = 302;
            Response.Headers["Location"] = newUrl;
            return new EmptyResult();
           // return new RedirectResult(newUrl,permanent:false);
        }

        [HttpGet]
        [Route("NewEndPoint")]
        public IActionResult getNewEndPoint()
        {
            return Ok("New End Point");
        }
    }
}
