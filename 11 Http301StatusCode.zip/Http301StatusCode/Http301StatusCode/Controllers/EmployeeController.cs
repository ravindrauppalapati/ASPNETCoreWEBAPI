﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;

namespace Http301StatusCode.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class EmployeeController : ControllerBase
    {
        [HttpGet("old-Route")]
        public IActionResult GetfromOldRoute()
        {
            string newUrl = Url.Action("GetfromNewRoute", "Employee");
            Response.StatusCode = 301;
            Response.Headers["Location"] = newUrl;
            return new EmptyResult();
        }
        [HttpGet("new-Route")]
        public IActionResult GetfromNewRoute()
        {
            return Ok("This is New Location ");
        }
    }
}
