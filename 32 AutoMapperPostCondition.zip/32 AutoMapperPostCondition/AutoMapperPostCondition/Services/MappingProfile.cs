﻿using AutoMapper;
using AutoMapperPostCondition.DTOs;
using AutoMapperPostCondition.Models;

namespace AutoMapperPostCondition.Services
{
    public class MappingProfile : Profile
    {
        public MappingProfile()
        {
            CreateMap<Order, OrderDTO>()
                .AfterMap((src, dest) => { dest.Status = src.TotalAmount > 1000 ? "Premium" : "Standard"; });
        }
    }
}
