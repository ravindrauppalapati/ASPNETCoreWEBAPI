﻿using AutoMapper;
using AutoMapperPostCondition.DTOs;
using AutoMapperPostCondition.Models;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;

namespace AutoMapperPostCondition.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class OrderController : ControllerBase
    {
        private readonly IMapper _mapper;
        public OrderController(IMapper mapper)
        {
            _mapper = mapper;
        }

        List<Order> listOrders = new List<Order>()
        {
            new Order(){Id = 1,CustomerName="AAA",TotalAmount=900},
            new Order(){Id = 2,CustomerName="BBB",TotalAmount=1000},
            new Order(){Id = 3,CustomerName="CCC",TotalAmount=2000},
            new Order(){Id = 4,CustomerName="DDD",TotalAmount=1900},
        };

        [HttpGet("{id}")]
        public ActionResult<OrderDTO> GetOrder(int id)
        {
            var order = listOrders.Where(x => x.Id == id).FirstOrDefault(); 
            var orderDto = _mapper.Map<OrderDTO>(order);
            return Ok(orderDto);
        }
    }
}
