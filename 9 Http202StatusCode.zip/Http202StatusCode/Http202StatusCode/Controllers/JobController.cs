﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;

namespace Http202StatusCode.Controllers
{ 
    [Route("api/[controller]/[action]")]
    [ApiController]
    public class JobController : ControllerBase
    {
        //[HttpGet("{JobId}")]
        //public IActionResult GetStatus(int JobId)
        //{
        //    var resourceStatus = new { Status = "Processing", EstimatedTime = "2 hours" };
        //    return Ok(resourceStatus);
        //}
        //private async Task LongRunningTask()
        //{
        //    await Task.Delay(TimeSpan.FromSeconds(5));
        //}
        //[HttpPost]
        //public async Task<IActionResult> CreateJobWithoutData()
        //{ 
        //   await LongRunningTask(); 
        //    return Accepted();
        //}

        //[HttpPost]
        //public async Task<IActionResult> CreateJobWithData()
        //{ 
        //  await  LongRunningTask(); 
        //    var resourceStatus = new
        //    {
        //        Status = "Processing",
        //        EstimatedTime = "2 hours"
        //    }; 
        //    return Accepted(resourceStatus);
        //} 

        //[HttpPost]
        //public async Task<IActionResult> CreateJobWithLocation()
        //{

        //  await  LongRunningTask(); 

        //    var processingJobId = 123; 

        //    var locationUrl = Url.Action("GetStatus", new { JobId = processingJobId }); 

        //    if (string.IsNullOrEmpty(locationUrl))
        //    { 
        //        return BadRequest("Unable to generate status URL.");
        //    } 
        //    var locationUri = new Uri(locationUrl, UriKind.RelativeOrAbsolute); 
        //    return Accepted(locationUri);
        //}

        //[HttpPost]
        //public async Task<IActionResult> CreateJobWithLocationAndData()
        //{
        //    await LongRunningTask(); 

        //    var processingJobId = 123; 

        //    var resourceStatus = new
        //    {
        //        Status = "Processing",
        //        EstimatedTime = "2 hours",
        //        JobId = processingJobId
        //    };

        //    var locationUrl = Url.Action("GetStatus", new { JobId = processingJobId }); 
        //    if (string.IsNullOrEmpty(locationUrl))
        //    { 
        //        return BadRequest("Unable to generate status URL.");
        //    } 
        //    var locationUri = new Uri(locationUrl, UriKind.RelativeOrAbsolute); 
        //    return Accepted(locationUri, resourceStatus);
        //} 

        ////=======================================================================================
        #region AcceptAtAction

        //[HttpGet("{JobId}")]
        //public IActionResult GetStatus(int JobId)
        //{
        //    var resourceStatus = new { Status = "Processing", EstimatedTime = "2 hours" };
        //    return Ok(resourceStatus);
        //}
        //private async Task LongRunningTask()
        //{
        //    await Task.Delay(TimeSpan.FromSeconds(3));
        //}
        //[HttpPost]
        //public async Task<IActionResult> CreateJobWithLocation()
        //{
        //    await LongRunningTask();
        //    var processingJobId = 123;
        //    return AcceptedAtAction("GetStatus", new { JobId = processingJobId }, null);
        //}
        //[HttpPost]
        //public async Task<IActionResult> CreateJobWithLocationAndData()
        //{
        //    await LongRunningTask();
        //    var processingJobId = 123;
        //    var resourceStatus = new
        //    {
        //        Status = "Processing",
        //        EstimatedTime = "2 hours",
        //        JobId = processingJobId
        //    };
        //    return AcceptedAtAction("GetStatus", "Job", new { JobId = processingJobId }, resourceStatus);
        //}


        #endregion
        ////===========================================================================
        #region AcceptAtRoute

        [HttpGet("{JobId}", Name = "GetJobStatus")]
        public IActionResult GetStatus(int JobId)
        {
            var resourceStatus = new { Status = "Processing", EstimatedTime = "2 hours" };
            return Ok(resourceStatus);
        }
        private async Task LongRunningTask()
        {
            await Task.Delay(TimeSpan.FromSeconds(3));
        }
        [HttpPost]
        public async Task<IActionResult> CreateJobWithLocation()
        {
            await LongRunningTask();
            var processingJobId = 123;
            return AcceptedAtRoute("GetJobStatus", new { JobId = processingJobId });
        }
        [HttpPost]
        public async Task<IActionResult> CreateJobWithLocationAndData()
        {
            await LongRunningTask();
            var processingJobId = 123;
            var resourceStatus = new
            {
                Status = "Processing",
                EstimatedTime = "2 hours",
                JobId = processingJobId
            };
            return AcceptedAtRoute(new { controller = "Job", action = "GetStatus", JobId = processingJobId }, resourceStatus);
        }
       
        #endregion
    }
}
