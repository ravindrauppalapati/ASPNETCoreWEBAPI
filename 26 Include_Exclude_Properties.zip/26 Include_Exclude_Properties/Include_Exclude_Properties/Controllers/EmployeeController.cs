﻿using Include_Exclude_Properties.Models;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;

namespace Include_Exclude_Properties.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class EmployeeController : ControllerBase
    {
        private List<Employee> listEmployees = new List<Employee>()
        {
            new Employee(){ Id = 1, Name = "AAA", Age = 28, Salary=1000, Gender = "Male", Department = "IT" },
            new Employee(){ Id = 2, Name = "BBB", Age = 28, Salary=2000, Gender = "Male", Department = "IT" },
        };

        //[HttpGet]
        //public ActionResult<List<Employee>> GetEmployees()
        //{
        //    return Ok(listEmployees);
        //}
        //[HttpPost]
        //public ActionResult<Employee> AddEmployee(Employee employee)
        //{
        //    if (employee != null)
        //    { 
        //        employee.Id = listEmployees.Count + 1;
        //        employee.Salary = 3000;
        //        listEmployees.Add(employee);
        //        return Ok(employee);
        //    }
        //    return BadRequest();
        //}
        //====================================================
        
        [HttpGet]
        public ActionResult<List<EmployeeDTO>> GetEmployees()
        {
            List<EmployeeDTO> employees = new List<EmployeeDTO>();
            foreach (var employee in listEmployees)
            {
                EmployeeDTO emp = new EmployeeDTO()
                { 
                    Name = employee.Name,
                    Age = employee.Age,
                    Gender = employee.Gender,
                    Department = employee.Department,
                };
                employees.Add(emp);
            }
            return Ok(employees);
        }
        [HttpPost]
        public ActionResult<EmployeeDTO> AddEmployee(EmployeeDTO employee)
        {
            if (employee != null)
            {
                Employee emp = new Employee()
                { 
                    Id = listEmployees.Count + 1,
                    Salary = 3000, 
                    Name = employee.Name,
                    Age = employee.Age,
                    Gender = employee.Gender,
                    Department = employee.Department,
                };

                listEmployees.Add(emp);
                return Ok(employee);
            }
            return BadRequest();
        }
    }
}
