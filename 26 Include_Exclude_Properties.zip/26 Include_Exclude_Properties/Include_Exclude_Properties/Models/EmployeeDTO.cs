﻿namespace Include_Exclude_Properties.Models
{
    public class EmployeeDTO
    { 
            public string Name { get; set; }
            public string Gender { get; set; }
            public int Age { get; set; }
            public string Department { get; set; } 
    }
}
