﻿using System.Text.Json.Serialization;

namespace Include_Exclude_Properties.Models
{
    public class Employee
    {
        public int Id { get; set; }
        public string Name { get; set; }
        public string Gender { get; set; }
        public int Age { get; set; }
        public int Salary { get; set; }
        public string Department { get; set; }

        //[JsonIgnore]
        //public int Id { get; set; }
        //public string Name { get; set; }
        //public string Gender { get; set; }
        //public int Age { get; set; }
        //[JsonIgnore]
        //public int Salary { get; set; }
        //public string Department { get; set; }
    }
}
