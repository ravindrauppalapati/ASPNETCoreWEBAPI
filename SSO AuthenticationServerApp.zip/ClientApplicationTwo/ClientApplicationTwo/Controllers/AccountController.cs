﻿using Microsoft.AspNetCore.Mvc;
using ClientApplicationTwo.Models; 
using Newtonsoft.Json.Linq;
using ClientApplicationTwo.Services;
namespace ClientApplicationTwo.Controllers
{
    public class AccountController : Controller
    {
        private readonly AuthenticationService _authService;
        private readonly IConfiguration _configuration;

        public AccountController(AuthenticationService authService, IConfiguration configuration)
        {
            _authService = authService;
            _configuration = configuration;
        }

        [HttpGet]
        public IActionResult Register()
        {
            return View();
        }

        [HttpPost]
        public async Task<IActionResult> Register(RegisterViewModel model)
        {
            if (!ModelState.IsValid)
            {
                return View(model);
            }

            var response = await _authService.RegisterUserAsync(model);

            if (response.IsSuccessful)
            {
                return RedirectToAction("Login");
            }

            ModelState.AddModelError(string.Empty, "Registration Failed.");
            return View();
        }

        [HttpGet]
        public IActionResult Login()
        {
            return View();
        }

        [HttpPost]
        public async Task<IActionResult> Login(LoginViewModel model)
        {
            if (!ModelState.IsValid)
            {
                return View(model);
            }

            var response = await _authService.LoginUserAsync(model);

            if (response.IsSuccessful)
            {
                var responseContent = response.Content;

                try
                {
                    var jsonObject = JObject.Parse(responseContent);

                    if (jsonObject["Token"] != null)
                    {
                        var token = jsonObject["Token"].ToString();

                        HttpContext.Session.SetString("JWT", token);

                        HttpContext.Session.SetString("Username", model.UserName);

                        return RedirectToAction("Index", "Home");
                    }
                    else
                    {
                        ModelState.AddModelError(string.Empty, "Token not found in the response.");
                        return View();
                    }
                }
                catch (Exception ex)
                {
                    Console.WriteLine("Error parsing response: " + ex.Message);
                    ModelState.AddModelError(string.Empty, "Failed to parse the response.");
                    return View();
                }
            }

            ModelState.AddModelError(string.Empty, "Login failed.");
            return View();
        }

        [HttpGet]
        public async Task<IActionResult> GenerateSSOToken()
        {
            var token = HttpContext.Session.GetString("JWT");
            if (string.IsNullOrEmpty(token))
            {
                return RedirectToAction("Login", "Account");
            }

            var response = await _authService.GenerateSSOTokenAsync(token);

            if (response.IsSuccessful)
            {
                var ssoToken = JObject.Parse(response.Content)["SSOToken"].ToString();

                var clientAppOneUrl = _configuration["ClientApplicationOne:BaseUrl"];
                return Redirect($"{clientAppOneUrl}/validate-sso?ssoToken={ssoToken}");
            }

            ViewBag.Error = "Failed to generate SSO token.";
            return View("Error");
        }

        [HttpPost]
        public IActionResult Logout()
        {
            HttpContext.Session.Remove("JWT");
            HttpContext.Session.Remove("Username");
            return RedirectToAction("Index", "Home");
        }
    }
}
