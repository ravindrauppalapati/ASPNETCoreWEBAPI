﻿using Microsoft.AspNetCore.Mvc;
using ClientApplicationOne.Models;
using Newtonsoft.Json.Linq;
using ClientApplicationOne.Services;


namespace ClientApplicationOne.Controllers
{
    public class AccountController : Controller
    {
        private readonly AuthenticationService _authService;

        public AccountController(AuthenticationService authService)
        {
            _authService = authService;
        }

        [HttpGet]
        public IActionResult Register()
        {
            return View();
        }

        [HttpPost]
        public async Task<IActionResult> Register(RegisterViewModel model)
        {
            if (!ModelState.IsValid)
            {
                return View(model);
            }

            var response = await _authService.RegisterUserAsync(model);

            if (response.IsSuccessful)
            {
                return RedirectToAction("Login");
            }

            ModelState.AddModelError(string.Empty, "Registration Failed.");
            return View();
        }

        [HttpGet]
        public IActionResult Login()
        {
            return View();
        }

        [HttpPost]
        public async Task<IActionResult> Login(LoginViewModel model)
        {
            if (!ModelState.IsValid)
            {
                return View(model);
            }

            var response = await _authService.LoginUserAsync(model);

            if (response.IsSuccessful)
            {
                var responseContent = response.Content;

                try
                {
                    var jsonObject = JObject.Parse(responseContent);

                    if (jsonObject["Token"] != null)
                    {
                        var token = jsonObject["Token"].ToString();

                        HttpContext.Session.SetString("JWT", token);

                        HttpContext.Session.SetString("Username", model.UserName);

                        return RedirectToAction("Index", "Home");
                    }
                    else
                    {
                        ModelState.AddModelError(string.Empty, "Token not found in the response.");
                        return View();
                    }
                }
                catch (Exception ex)
                {
                    Console.WriteLine("Error parsing response: " + ex.Message);
                    ModelState.AddModelError(string.Empty, "Failed to parse the response.");
                    return View();
                }
            }

            ModelState.AddModelError(string.Empty, "Login failed.");
            return View();
        }

        [HttpPost]
        public IActionResult Logout()
        {
            HttpContext.Session.Remove("JWT");
            HttpContext.Session.Remove("Username");
            return RedirectToAction("Index", "Home");
        }

        [HttpGet("validate-sso")]
        public async Task<IActionResult> ValidateSSO([FromQuery] string ssoToken)
        {
            if (string.IsNullOrEmpty(ssoToken))
            {
                return RedirectToAction("Login");
            }

            var response = await _authService.ValidateSSOTokenAsync(ssoToken);

            if (response.IsSuccessful)
            {
                var responseContent = response.Content;

                try
                {
                    var jsonObject = JObject.Parse(responseContent);

                    var accessToken = jsonObject["Token"]?.ToString();
                    var username = jsonObject["UserDetails"]?["Username"]?.ToString();

                    if (!string.IsNullOrEmpty(accessToken))
                    {
                        HttpContext.Session.SetString("JWT", accessToken);
                    }

                    if (!string.IsNullOrEmpty(username))
                    {
                        HttpContext.Session.SetString("Username", username);
                    }

                    return RedirectToAction("Index", "Home");
                }
                catch (Exception ex)
                {
                    Console.WriteLine("Error parsing response: " + ex.Message);
                    return RedirectToAction("Login");
                }
            }

            return RedirectToAction("Login");
        }
    }
}


