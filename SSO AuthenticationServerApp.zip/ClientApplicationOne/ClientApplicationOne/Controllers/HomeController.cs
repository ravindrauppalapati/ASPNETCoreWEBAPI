using ClientApplicationOne.Models;
using Microsoft.AspNetCore.Mvc;
using Newtonsoft.Json.Linq;
using RestSharp;
using System.Diagnostics;

namespace ClientApplicationOne.Controllers
{
    public class HomeController : Controller
    {
        private readonly IConfiguration _configuration;
        private readonly string? _authServerUrl;
        public HomeController(IConfiguration configuration)
        {
            _configuration = configuration;
            _authServerUrl = _configuration["ResourceServer:BaseUrl"];
        }
        public IActionResult Index()
        {
            return View();
        }
        [HttpGet]
        public async Task<IActionResult> GetPublicData()
        {
            var client = new RestClient($"{_authServerUrl}/api/Resource/public-data");
            var request = new RestRequest();
            request.Method = Method.Get;
            var response = await client.ExecuteAsync(request);
            if (response.IsSuccessful)
            {
                try
                {
                    var jsonObject = JObject.Parse(response.Content);
                    if (jsonObject["Message"] != null)
                    {
                        ViewBag.PublicData = jsonObject["Message"].ToString();
                    }
                    else
                    {
                        ViewBag.PublicData = "No message found in the response.";
                    }
                }
                catch (Exception ex)
                {
                    ViewBag.Error = "Error parsing the response: " + ex.Message;
                }
                return View();
            }
            ViewBag.Error = "Failed to retrieve public data.";
            return View();
        }
        [HttpGet]
        public async Task<IActionResult> GetProtectedData()
        {
            var token = HttpContext.Session.GetString("JWT");
            if (string.IsNullOrEmpty(token))
            {
                return RedirectToAction("Login", "Account");
            }
            var client = new RestClient($"{_authServerUrl}/api/Resource/protected-data");
            var request = new RestRequest();
            request.Method = Method.Get;
            request.AddHeader("Authorization", $"Bearer {token}");
            var response = await client.ExecuteAsync(request);
            if (response.IsSuccessful)
            {
                try
                {
                    var jsonObject = JObject.Parse(response.Content);
                    if (jsonObject["Message"] != null)
                    {
                        ViewBag.ProtectedData = jsonObject["Message"].ToString();
                    }
                    else
                    {
                        ViewBag.ProtectedData = "No message found in the response.";
                    }
                }
                catch (Exception ex)
                {
                    ViewBag.Error = "Error parsing the response: " + ex.Message;
                }
                return View();
            }
            ViewBag.Error = "Failed to retrieve protected data or unauthorized.";
            return View();
        }
    }
}
