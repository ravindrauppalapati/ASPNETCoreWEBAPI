﻿using ClientApplicationOne.Models;
using RestSharp;
namespace ClientApplicationOne.Services
{
    public class AuthenticationService
    {
        private readonly IConfiguration _configuration;
        private readonly string? _authServerUrl;

        public AuthenticationService(IConfiguration configuration)
        {
            _configuration = configuration;
            _authServerUrl = _configuration["AuthenticationServer:BaseUrl"];
        }

        public async Task<RestResponse> RegisterUserAsync(RegisterViewModel model)
        {
            var client = new RestClient($"{_authServerUrl}/api/authentication/register");

            var request = new RestRequest();
            request.Method = Method.Post;

            request.AddJsonBody(model);

            return await client.ExecuteAsync(request);
        }

        public async Task<RestResponse> LoginUserAsync(LoginViewModel model)
        {
            var client = new RestClient($"{_authServerUrl}/api/Authentication/login");

            var request = new RestRequest();
            request.Method = Method.Post;

            request.AddJsonBody(new { Username = model.UserName, Password = model.Password });
            return await client.ExecuteAsync(request);
        }

        public async Task<RestResponse> ValidateSSOTokenAsync(string ssoToken)
        {
            var client = new RestClient($"{_authServerUrl}/api/authentication/validate-sso-token");

            var request = new RestRequest();
            request.Method = Method.Post;

            request.AddJsonBody(new { SSOToken = ssoToken });

            return await client.ExecuteAsync(request);
        }
    }
}
