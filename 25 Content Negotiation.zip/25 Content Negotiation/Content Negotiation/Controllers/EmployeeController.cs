﻿using Content_Negotiation.Models;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;

namespace Content_Negotiation.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class EmployeeController : ControllerBase
    { //GET api/employee
        [HttpGet]
        public ActionResult<List<Employee>> GetEmployees()
        {
            var listEmployees = new List<Employee>()
            {
                new Employee(){ Id = 1001, Name = "AAA", Age = 28, Gender = "Male", Department = "IT" },
                new Employee(){ Id = 1002, Name = "BBB", Age = 28, Gender = "Male", Department = "IT" },
            };
            return Ok(listEmployees);
        }
    }
}
