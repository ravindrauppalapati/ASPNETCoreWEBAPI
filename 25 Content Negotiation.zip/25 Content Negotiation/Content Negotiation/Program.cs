
namespace Content_Negotiation
{
    public class Program
    {
        public static void Main(string[] args)
        {
            var builder = WebApplication.CreateBuilder(args);

            // Add services to the container.

            builder.Services.AddControllers();
            // Learn more about configuring Swagger/OpenAPI at https://aka.ms/aspnetcore/swashbuckle
            builder.Services.AddEndpointsApiExplorer();
            builder.Services.AddSwaggerGen();

            //builder.Services.AddControllers()
            //    .AddXmlSerializerFormatters();

            //builder.Services.AddControllers(options =>
            //{ 
            //    options.OutputFormatters.RemoveType<Microsoft.AspNetCore.Mvc.Formatters.SystemTextJsonOutputFormatter>();
            //}).AddXmlSerializerFormatters();  

            //builder.Services.AddControllers(options =>
            //{ 
            //    options.ReturnHttpNotAcceptable = true;
            //}) 
            //.AddJsonOptions(options =>
            //{ 
            //     options.JsonSerializerOptions.PropertyNamingPolicy = null;
            //});

            var app = builder.Build();

            // Configure the HTTP request pipeline.
            if (app.Environment.IsDevelopment())
            {
                app.UseSwagger();
                app.UseSwaggerUI();
            }

            app.UseHttpsRedirection();

            app.UseAuthorization();

           // app.UseMiddleware<CustomNotAcceptableMiddleware>();

            app.MapControllers();

            app.Run();
        }
    }
}
