﻿using System.Net.Http.Headers;
using System.Net.Http.Json;
using System.Text;

namespace BasicAuthClient
{
    internal class Program
    {
        static HttpClient client = new HttpClient();

        static async Task Main(string[] args)
        {
            client.BaseAddress = new Uri("https://localhost:7127");

            client.DefaultRequestHeaders.Accept.Clear();

            client.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));

            var byteArray = Encoding.ASCII.GetBytes("admin:admin");
            client.DefaultRequestHeaders.Authorization = new AuthenticationHeaderValue("Basic", Convert.ToBase64String(byteArray));

            try
            {
                Console.WriteLine("Getting all users...");
                var users = await GetAsync("api/user");
                Console.WriteLine(users);

                Console.WriteLine("Creating a new user...");
                var newUser = new { Id = 5, Username = "newuser", Password = "newpassword" };
                var postResult = await PostAsync("api/user", newUser);
                Console.WriteLine(postResult);

                Console.WriteLine("Updating a user...");
                var updatedUser = new { Id = 5, Username = "updateduser", Password = "updatedpassword" };
                var putResult = await PutAsync("api/user/5", updatedUser);
                Console.WriteLine(putResult);

                Console.WriteLine("Deleting a user...");
                var deleteResult = await DeleteAsync("api/user/5");
                Console.WriteLine(deleteResult);

                Console.ReadKey();
            }
            catch (Exception e)
            {
                Console.WriteLine(e.Message);
            }
        }

        static async Task<string> GetAsync(string path)
        {
            HttpResponseMessage response = await client.GetAsync(path);
            return response.IsSuccessStatusCode ? await response.Content.ReadAsStringAsync() : $"Error: {response.StatusCode}";
        }

        static async Task<string> PostAsync(string path, object value)
        {
            HttpResponseMessage response = await client.PostAsJsonAsync(path, value);
            return response.IsSuccessStatusCode ? await response.Content.ReadAsStringAsync() : $"Error: {response.StatusCode}";
        }

        static async Task<string> PutAsync(string path, object value)
        {
            HttpResponseMessage response = await client.PutAsJsonAsync(path, value);
            return response.IsSuccessStatusCode ? "Updated successfully." : $"Error: {response.StatusCode}";
        }

        static async Task<string> DeleteAsync(string path)
        {
            HttpResponseMessage response = await client.DeleteAsync(path);
            return response.IsSuccessStatusCode ? "Deleted successfully." : $"Error: {response.StatusCode}";
        }
    }
}
