﻿using BasicAuthApp.Models; 
namespace BasicAuthApp.Repository
{
    public interface IUserRepository
    {
        Task<User?> ValidateUser(string username, string password);
        Task<List<User>> GetAllUsers();
        Task<User?> GetUserById(int id);
        Task<User> AddUser(User user);
        Task<User> UpdateUser(User user);
        Task DeleteUser(int id);
    }
    public class UserRepository : IUserRepository
    {
             private List<User> users = new List<User>
            {
                new User { Id = 1, Username = "admin", Password = "admin" },
                new User { Id = 2, Username = "user", Password = "user" },
                new User { Id = 3, Username = "Test", Password = "Test@1234" },
                new User { Id = 4, Username = "Ravi", Password = "Admin@123" }
            };
        public async Task<User> AddUser(User user)
        {
            await Task.Delay(100);
            if (users.Any(u => u.Id == user.Id))
            {
                throw new Exception("User already exists with the given ID.");
            }

            users.Add(user);
            return user;
        }

        public async Task DeleteUser(int id)
        {
            await Task.Delay(100);
            var user = await GetUserById(id);
            if (user == null)
            {
                throw new Exception("User not found.");
            }

            users.Remove(user);
        }

        public async Task<List<User>> GetAllUsers()
        {
            await Task.Delay(100);
            return users.ToList();
        }

        public async Task<User?> GetUserById(int id)
        {
            await Task.Delay(100);
            return users.FirstOrDefault(u => u.Id == id);
        }

        public async Task<User> UpdateUser(User user)
        {
            await Task.Delay(100);
            var existingUser = await GetUserById(user.Id);
            if (existingUser == null)
            {
                throw new Exception("User not found.");
            }

            existingUser.Username = user.Username;
            existingUser.Password = user.Password;
            return existingUser;
        }

        public async Task<User?> ValidateUser(string username, string password)
        {
            await Task.Delay(100);
            return users.FirstOrDefault(u => u.Username == username && u.Password == password);
        }
    }
}
