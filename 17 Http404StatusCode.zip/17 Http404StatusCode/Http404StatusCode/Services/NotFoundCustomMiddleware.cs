﻿using System.Text.Json;

namespace Http404StatusCode.Services
{
    public class NotFoundCustomMiddleware
    {
        private readonly RequestDelegate _next; 
        public NotFoundCustomMiddleware(RequestDelegate next)
        {
            _next = next;  
        } 
        public async Task Invoke(HttpContext context)
        {
            bool isAuthorized = false;
            if (!isAuthorized)
            {
                context.Response.StatusCode = StatusCodes.Status404NotFound;
                context.Response.ContentType = "application/json";
                var customResponse = new
                {
                    Code = 404,
                    Message = "Endpoint does not exist"
                };
                var responseJson = JsonSerializer.Serialize(customResponse);
                await context.Response.WriteAsync(responseJson);
                return;
            }
            await _next(context);
        }
    }
}
