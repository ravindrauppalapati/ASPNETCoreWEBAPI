﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;

namespace Http404StatusCode.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class EmployeeController : ControllerBase
    {
        //[HttpGet("{id}")]
        //public IActionResult GetResource(int id)
        //{
        //    var resource = FindResourceById(id);
        //    if (resource == null)
        //    {
        //        return NotFound();
        //    }

        //    return Ok(resource);
        //}
        //private object FindResourceById(int id)
        //{
        //    return null;
        //}
        //==========================================================
        //[HttpGet("{id}")]
        //public IActionResult GetResource(int id)
        //{
        //    var resource = FindResourceById(id);
        //    if (resource == null)
        //    {
        //        var customResponse = new { message = $"No Employee Found with the Id: {id}" };
        //        return NotFound(customResponse);
        //    }
        //    return Ok(resource);
        //}
        //private object FindResourceById(int id)
        //{
        //    return null;
        //}
        //==============================================================
        //[HttpGet("{id}")]
        //public IActionResult GetResource(int id)
        //{
        //    var resource = FindResourceById(id);
        //    if (resource == null)
        //    {
        //        var customResponse = new { message = $"No Employee Found with the Id: {id}" };
        //        return StatusCode(StatusCodes.Status404NotFound, customResponse);
        //    }
        //    return Ok(resource);
        //}
        //private object FindResourceById(int id)
        //{
        //    return null;
        //}
        //================================================================
        [HttpGet("{id}")]
        public IActionResult GetResource(int id)
        {
            return Ok("EMP Found");
        }
    }
}
