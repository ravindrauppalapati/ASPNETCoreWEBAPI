﻿namespace AutoMapperCondition.DTOs
{
    public class ProductDTO
    {
        public int Id { get; set; }
        public string ItemName { get; set; }
        public int ItemQuantity { get; set; }
        public int Amount { get; set; }
    }
}
