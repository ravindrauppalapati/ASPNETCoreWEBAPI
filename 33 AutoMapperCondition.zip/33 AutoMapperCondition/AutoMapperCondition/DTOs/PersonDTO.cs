﻿namespace AutoMapperCondition.DTOs
{
    public class PersonDTO
    {
        public string Name { get; set; }
        public int? Age { get; set; }
    }
}
