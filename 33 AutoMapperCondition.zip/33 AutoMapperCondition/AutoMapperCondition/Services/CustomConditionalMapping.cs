﻿namespace AutoMapperCondition.Services
{
    public class CustomConditionalMapping
    {
        public static bool IsNameMap(string name)
        {
            return name.StartsWith("A");
        }

        public static bool IsQuantityMap(int  quantity)
        {
            return quantity > 0;
        }
        public static bool IsAmountMap(int amount)
        {
            return amount > 100;
        }
    }
}
