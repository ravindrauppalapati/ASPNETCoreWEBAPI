﻿using AutoMapper;
using AutoMapperCondition.DTOs;
using AutoMapperCondition.Models;

namespace AutoMapperCondition.Services
{
    public class MappingProfile : Profile
    {
        public MappingProfile()
        {
            //CreateMap<Product, ProductDTO>()
            //    .ForMember(dest => dest.ItemQuantity, act => act.MapFrom(src => src.Quantity))
            //    .ForMember(dest => dest.ItemName, act => act.MapFrom(src => (src.Name.StartsWith("A") ? src.Name : src.OptionalName)))
            //    .ForMember(dest => dest.ItemQuantity, act => act.Condition(src => src.Quantity > 0))
            //    .ForMember(dest => dest.Amount, act => act.Condition(src => src.Amount > 100));


            //CreateMap<Product, ProductDTO>()
            //    .ForMember(dest => dest.ItemQuantity, act => act.MapFrom(src => src.Quantity))
            //    .ForMember(dest => dest.ItemName, act => act.MapFrom(src => (CustomConditionalMapping.IsNameMap(src.Name) ? src.Name : src.OptionalName)))
            //    .ForMember(dest => dest.ItemQuantity, act => act.Condition(src => (CustomConditionalMapping.IsQuantityMap(src.Quantity))))
            //    .ForMember(dest => dest.Amount, act => act.Condition(src => (CustomConditionalMapping.IsAmountMap(src.Amount))));

            CreateMap<PersonDTO, Person>()
                .ForMember(dest => dest.Age, act => act.Condition(src => src.Age > 18 && src.Age < 60));

        }
    }
}
