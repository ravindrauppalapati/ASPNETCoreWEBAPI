﻿using AutoMapper;
using AutoMapperCondition.DTOs;
using AutoMapperCondition.Models;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;

namespace AutoMapperCondition.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class ProductController : ControllerBase
    {
        private readonly IMapper _mapper; 
        public ProductController(IMapper mapper)
        { 
            _mapper = mapper;
        }
        private List<Product> listProducts = new List<Product>()
        {
            new Product { Id = 1001, Name="Laptop", OptionalName="Gaming Laptop", Amount = 1000, Quantity = 10},
            new Product { Id = 1002, Name="Apple Laptop", OptionalName="Programming Apple Laptop", Amount = 2000, Quantity = 0}
        };
        [HttpGet("{Id}")]
        public ActionResult<ProductDTO> GetProductById(int Id)
        {
            Product? product = listProducts.FirstOrDefault(x => x.Id == Id);
            if (product != null)
            { 
                var productDTO = _mapper.Map<ProductDTO>(product);
                return Ok(productDTO);
            }
            return BadRequest("Product Not Found");
        }

        [HttpPost]
        public ActionResult<Person> AddPerson(PersonDTO model)
        {
            var person = _mapper.Map<Person>(model);
            return Ok(person);
        }
    }
}
