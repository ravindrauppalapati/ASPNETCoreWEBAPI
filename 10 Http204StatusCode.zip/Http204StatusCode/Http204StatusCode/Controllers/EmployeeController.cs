﻿using Http204StatusCode.Models;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;

namespace Http204StatusCode.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class EmployeeController : ControllerBase
    {
        public List<Employee> employees = new List<Employee>()
        {
            new Employee(){ Id=1,Name="AAA",Gender="Male",PhoneNo="12345",Address="GTR"},
            new Employee(){ Id=2,Name="BBB",Gender="FeMale",PhoneNo="12343",Address="VZG"},
            new Employee(){ Id=3,Name="CCC",Gender="Male",PhoneNo="12342",Address="GTR"},
            new Employee(){ Id=4,Name="DDD",Gender="FeMale",PhoneNo="12341",Address="VJW"},
            new Employee(){ Id=5,Name="EEE",Gender="Male",PhoneNo="12344",Address="HYD"},
        };

        [HttpPut("{id}")]
        public IActionResult UpdateEmployee(int id, Employee employee)
        {
            if (id != employee.Id)
            {
                return BadRequest();
            }

            var emp = employees.Where(x => x.Id == id).FirstOrDefault();
            if (emp == null)
            {
                return NotFound();
            }

            emp.Name = employee.Name;
            emp.Gender = employee.Gender;
            emp.PhoneNo = employee.PhoneNo;
            emp.Address = employee.Address;

            return StatusCode(StatusCodes.Status204NoContent);
        }
    }
}
