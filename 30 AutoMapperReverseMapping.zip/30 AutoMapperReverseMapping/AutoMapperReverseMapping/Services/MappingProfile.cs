﻿using AutoMapper;
using AutoMapperReverseMapping.DTOs;
using AutoMapperReverseMapping.Models;
namespace AutoMapperReverseMapping.Services
{
    public class MappingProfile : Profile
    {
        public MappingProfile() 
        {
            CreateMap<Employee, EmployeeDTO>()
                   .ForMember(dest => dest.EmployeeId, act => act.MapFrom(src => src.Id))
                   .ForMember(dest => dest.City, act => act.MapFrom(src => src.address.City))
                   .ForMember(dest => dest.State, act => act.MapFrom(src => src.address.State))
                   .ForMember(dest => dest.Country, act => act.MapFrom(src => src.address.Country))
                   .ReverseMap();
        }
    }
}
