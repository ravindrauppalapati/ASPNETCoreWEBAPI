﻿using AutoMapper;
using AutoMapperReverseMapping.DTOs;
using AutoMapperReverseMapping.Models;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;

namespace AutoMapperReverseMapping.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class EmployeeController : ControllerBase
    {
        private readonly IMapper _mapper;
        public EmployeeController(IMapper mapper)
        {
            _mapper = mapper;
        }
        private List<Employee> listEmployees = new List<Employee>()
        {
            new Employee()
            {
                Id = 1, Name = "Ravindra", Gender = "Male", Email = "Ravindra@Example.com",
                address = new Address(){Id= 1001, City ="GTR", State = "Andhra", Country = "India"}
            },
            new Employee()
            {
                Id = 2, Name = "Narendra", Gender = "Male", Email = "Narendra@Example.com",
                address = new Address(){Id= 1002, City ="GTR", State = "Andhra", Country = "India"}
            },
        };

        [HttpGet]
        public ActionResult<List<EmployeeDTO>> getEmployees()
        {
            var employees = _mapper.Map<List<EmployeeDTO>>(listEmployees);
            return Ok(employees);
        }

        [HttpPost]
        public ActionResult<List<Employee>> createEmployee(EmployeeDTO employeeDTO)
        {
            var emp = _mapper.Map<Employee>(employeeDTO);

            listEmployees.Add(emp);

            return Ok(listEmployees);
        }

    }
}
