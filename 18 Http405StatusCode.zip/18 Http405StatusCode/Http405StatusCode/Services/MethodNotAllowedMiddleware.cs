﻿using System.Net;
using System.Text.Json;

namespace Http405StatusCode.Services
{
    public class MethodNotAllowedMiddleware
    {
        private readonly RequestDelegate _next; 
        public MethodNotAllowedMiddleware(RequestDelegate next)
        {
            _next = next;  
        } 
        public async Task Invoke(HttpContext context)
        { 
            await _next(context); 
            if (context.Response.StatusCode == (int)HttpStatusCode.MethodNotAllowed)
            { 
                context.Response.ContentType = "application/json"; 
                var customResponse = new
                { 
                    Code = 405, 
                    Message = "HTTP Method not allowed"
                }; 
                var responseJson = JsonSerializer.Serialize(customResponse); 
                await context.Response.WriteAsync(responseJson);
            }
        }
    }
}
