﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;

namespace Http405StatusCode.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class EmployeeController : ControllerBase
    {
        //[HttpPost]
        //public IActionResult PostAction()
        //{
        //    return Ok("Data processed");
        //}
        //=============================================================

        //public IActionResult UnifiedMethod()
        //{
        //    if (HttpContext.Request.Method == HttpMethod.Post.Method)
        //    {
        //        return Ok("Handled POST request");
        //    }
        //    else if (HttpContext.Request.Method == HttpMethod.Put.Method)
        //    {
        //        return Ok("Handled PUT request");
        //    }
        //    else
        //    {
        //        var customResponse = new
        //        {
        //            Code = 405,
        //            Message = "Support Method are POST and PUT"
        //        };
        //        return StatusCode(StatusCodes.Status405MethodNotAllowed, customResponse);
        //    }
        //}
        //================================================================================
        [HttpPost]
        public IActionResult PostAction()
        {
            return Ok("Data processed");
        }
    }
}
