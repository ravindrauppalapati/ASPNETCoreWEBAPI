﻿using InMemoryCaching.Models;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Caching.Memory;
namespace InMemoryCaching.Repository
{
    public class LocationRepository
    {
        private readonly AppDBContext _context;
        private readonly IMemoryCache _cache;
       // private readonly TimeSpan _cacheExpiration = TimeSpan.FromMinutes(30);
        public LocationRepository(AppDBContext context, IMemoryCache cache)
        {
            _context = context;
            _cache = cache;
        }
        public async Task<List<Country>> GetCountriesAsync()
        {
            var cacheKey = "Countries"; 

            if (!_cache.TryGetValue(cacheKey, out List<Country>? countries))
            {
                countries = await _context.Countries.ToListAsync();
                _cache.Set(cacheKey, countries);
            }
            return countries ?? new List<Country>();
        }
        public void RemoveCountriesFromCache()
        { // manual eviction
            var cacheKey = "Countries";
            _cache.Remove(cacheKey);
        }

        public async Task UpdateCountry(Country updatedCountry)
        {
            _context.Countries.Update(updatedCountry);
            await _context.SaveChangesAsync();
            RemoveCountriesFromCache();
        }
        public async Task<List<State>> GetStatesAsync(int countryId)
        {
            string cacheKey = $"States_{countryId}";
            if (!_cache.TryGetValue(cacheKey, out List<State>? states))
            {
                var cacheEntryOptions = new MemoryCacheEntryOptions()
                    .SetSlidingExpiration(TimeSpan.FromMinutes(30));
                // Sliding eviction
                states = await _context.States.Where(s => s.CountryId == countryId).ToListAsync();
                _cache.Set(cacheKey, states, cacheEntryOptions);
            }
            return states ?? new List<State>();
        }
        public async Task<List<City>> GetCitiesAsync(int stateId)
        {
            string cacheKey = $"Cities_{stateId}";
            if (!_cache.TryGetValue(cacheKey, out List<City>? cities))
            {
                var cacheEntryOptions = new MemoryCacheEntryOptions()
                    .SetAbsoluteExpiration(TimeSpan.FromMinutes(30));
                // Absolute eviction
                cities = await _context.Cities.Where(c => c.StateId == stateId).ToListAsync();
                _cache.Set(cacheKey, cities, cacheEntryOptions);
            }
            return cities ?? new List<City>();
        }
    }
}
