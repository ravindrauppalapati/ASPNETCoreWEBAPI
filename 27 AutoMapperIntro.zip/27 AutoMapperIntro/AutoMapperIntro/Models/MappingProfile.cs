﻿using AutoMapper;
namespace AutoMapperIntro.Models
{
    public class MappingProfile : Profile
    {
        public MappingProfile()
        {
            //CreateMap<Employee,EmployeeDTO>();
            //CreateMap<EmployeeDTO,Employee>();
           
            CreateMap<Employee, EmployeeDTO>()
                .ForMember(d => d.FullName, act => act.MapFrom(s => s.Name))
                .ForMember(d => d.EmailId, act => act.MapFrom(s => s.Email));


            CreateMap<EmployeeDTO,Employee >()
               .ForMember(d => d.Name, act => act.MapFrom(s => s.FullName))
               .ForMember(d => d.Email, act => act.MapFrom(s => s.EmailId));
        }
    }
}
