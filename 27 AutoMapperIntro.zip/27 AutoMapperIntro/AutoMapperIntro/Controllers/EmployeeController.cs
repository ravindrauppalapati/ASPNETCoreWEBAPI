﻿using AutoMapper;
using AutoMapperIntro.Models;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;

namespace AutoMapperIntro.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class EmployeeController : ControllerBase
    {
        private readonly IMapper _mapper;
        public EmployeeController(IMapper mapper)
        {
            _mapper = mapper;
        }
        private List<Employee> empList = new List<Employee>()
        {
            new Employee(){Id=1,Name="Ravindra",Age=35,Email="Ravindra@gmail.com",Gender="Male",Salary=3000,SecurityNumber="123@Ravindra" },
            new Employee(){Id=2,Name="Narendra",Age=35,Email="Narendra@gmail.com",Gender="Male",Salary=4000,SecurityNumber="123@Narendra" }
        };

        [HttpGet]
        public ActionResult<List<EmployeeDTO>> getEmployees()
        {
            List<EmployeeDTO> employeeDTOs = _mapper.Map<List<EmployeeDTO>>(empList);

            //foreach (Employee employee in empList)
            //{
            //    EmployeeDTO emp = new EmployeeDTO()
            //    {
            //        Id=employee.Id,
            //        Name=employee.Name,
            //        Gender=employee.Gender,
            //        Age=employee.Age,
            //        Email = employee.Email,
            //    };
            //    employeeDTOs.Add(emp); 
            //}
            return Ok(employeeDTOs); 
        }

        [HttpPost]
        public ActionResult<EmployeeDTO> AddEmployee(EmployeeDTO employeeDTO)
        {
            Employee emp = _mapper.Map<Employee>(employeeDTO);
            emp.Salary = 500;
            emp.SecurityNumber = "123@AAA";
            //{
            //    Id = employeeDTO.Id,
            //    Name = employeeDTO.Name,
            //    Age = employeeDTO.Age,
            //    Email = employeeDTO.Email,
            //    Gender = employeeDTO.Gender,
            //    Salary = 5000,
            //    SecurityNumber="123@Jaanu"
            //};
            empList.Add(emp);
            return Ok(emp);
        } 
    }
}
